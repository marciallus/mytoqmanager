-- =============================================================================
--      Copyright (c) 2013-2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
-- ==============================================================================

-- TODO: Place the local city last

----------------------
-- Global variables --
----------------------

oo = require "oo"   -- get the Object Oriented library
ui = require "ui"   -- get the UI library
dt = require "datetime"
platform = require "platform"

-- The world time DateTimePrompt class
WorldTimePrompt = oo.class("WorldTimePrompt", ui.DateTimePrompt)


function WorldTimePrompt:modelChanged()
  self.superClass().modelChanged(self)

  local timeCoords = self:getCoords()
  local ampmCoords = g_worldAMPM:getCoords()
  local strWidth
  local font = { size=70 }
  local s = self:getProp{content=true}.content
  strWidth, _ = g_worldTime:getStringBBox(s, font)
  g_worldAMPM:move(timeCoords.left + strWidth + 5, ampmCoords.top)
end

--The World Clock class overrides the built-in Clock class
WorldClock = oo.class("WorldClock", ui.Clock)

-- Base part of zip files
g_appZip = "fms:/app.zip?"
g_worldZip = "fms:/ClockWorld.zip?"

-- The local time information widgets
g_localCity = nil
g_localTime = nil

-- Starting color for the local information
g_localColor = "m_63"

-- The world time information widgets, and a table to make
-- it easier to change colors, etc
g_worldCity = nil
g_worldTime = nil
g_worldAMPM = nil
g_worldDay  = nil
g_worldTemp = nil
g_worldWeather = nil

-- The widgets required to create the loading screen when
-- no world city data is available
g_loadingIcon = nil
g_loadingTitle = nil
g_loadingInfo = nil

-- The current index into the array of world cities
g_currentIndex = 1

-- Starting color for the world information
g_worldColor = "m_0"

-- Background image icon
g_backgroundIcon = nil

-- To be loaded from the zip file with the city data and images
-- g_currentCity = { "My Location" }
-- g_worldCities = {
--    { name = "San Diego",  folderName="SanDiego_California_USA",     gmtOffset = "-8:00" },
--    { name = "Paris",      folderName="Paris_France",                gmtOffset = "+1:00" },
--    { name = "Faisalabad", folderName="Faisalabad_Punjab_Pakistan",  gmtOffset = "+5:30" },
--    { name = "Cambridge",  folderName="Cambridge_Cambridgeshire_UK", gmtOffset = "0:00" },
-- } 
-- g_dummyData = true

g_currentCity = {}
g_worldCities = {}

function WorldClock:construct()
  print ("in construct")

  local layout = ui.Layout(self)

  -- draw the icon
  local bgPath = g_appZip .. "bg_world_ND.img"
  print (bgPath)

  g_backgroundIcon = layout:addIcon{path = bgPath}

  -- reset and draw text
  local leftMargin = 15
  layout:resetGeometry()
  layout:addVerticalSpace(13)
  layout:indent(leftMargin, 9)
  layout:hAlign(ui.LayoutHAlign.LEFT)

  -- Current city name
  local currentCityName = g_currentCity[1]
  if currentCityName == nil then
     -- Add initial data to ensure that the updated text will appear
    currentCityName = "My Location"
  end

  layout:setConstrainedWidth(170)
  g_localCity = layout:addText {
    content = currentCityName, 
    lines = 1, 
    color = g_localColor,
    font = { size=24 }
  }
  g_localCity:setProp { visible = false }

  -- Time in the top right corner
  local currentTimeModel = dt.DateTimeModel:getCurrentTime()
  layout:hAlign(ui.LayoutHAlign.RIGHT)
  layout:clearConstrainedWidth()
  layout:addVerticalSpace(-8)
  g_localTime = layout:addDateTime {
    value = currentTimeModel,
    format = "%I:%M", color = g_localColor, 
    font = { size=36, weight="bold" }
  }

  -- Reset to draw the world info
  layout:resetGeometry()
  layout:direction(ui.LayoutDirection.VERTICAL)
  layout:hAlign(ui.LayoutHAlign.LEFT)
  layout:addVerticalSpace(52)
  layout:indent(leftMargin)

  -- World City Name
  -- Add initial data to ensure that the updated text will appear
  g_worldCity = layout:addText {
     content = "World City", lines = 1, 
     color = g_worldColor,
     font = { size=36, weight="bold" },
  }
  g_worldCity:setProp { visible = false }

  -- World City Time
  layout:addVerticalSpace(-4)
  layout:direction(ui.LayoutDirection.HORIZONTAL)
  layout:setConstrainedWidth(170)
  print("creating g_worldTime")
  g_worldTime = WorldTimePrompt {
     value = currentTimeModel,
     format = "%I:%M", color = g_worldColor, 
     font = { size=70 }, 
     left = 0, top = 0, right = 100, bottom = 70,
  }
  layout:appendWidget(g_worldTime)
  g_worldTime:setProp { visible = false }

  -- World City AM/PM
  print("creating g_worldAMPM")
  layout:addVerticalSpace(37)
  g_worldAMPM = layout:addDateTime {
     value = currentTimeModel,
     format = "%p", color = g_worldColor, 
     font = { size=24, weight="bold" },
  }
  g_worldAMPM:setProp { visible = false }

  -- only set the model on the g_worldTime after we've created the g_worldAMPM
  -- widget since the modelChanged method requires that widget
  g_worldTime:setmodel(currentTimeModel)

  -- World Day
  print("creating g_worldDay")
  layout:resetGeometry()
  layout:indent(leftMargin)
  layout:addVerticalSpace(159)
  layout:setConstrainedWidth(154)
  g_worldDay = layout:addDateTime {
     value = currentTimeModel,
     format = "%#a, %#b %#d", color = g_worldColor, 
     font = { size=24, weight="bold" },
     visible = false
  }
  g_worldDay:setProp { visible = false }

  -- World Temperature
  print("creating g_worldTemp")
  layout:clearConstrainedWidth()
  layout:addVerticalSpace(-3)
  g_worldTemp = layout:addIcon{path = g_appZip .. "no_temp_black_ND.img"}
  g_worldTemp:setProp { visible = false }

  -- World Weather
  print("creating g_worldWeather")
  layout:addVerticalSpace(-21)
  g_worldWeather = layout:addIcon{path = g_appZip .. "no_icon_black_ND.img"}
  g_worldWeather:setProp { visible = false }

  -- Loading Screen widgets

  -- Loading Icon
  print("creating g_loadingIcon")
  layout:resetGeometry()
  layout:indent(12)
  layout:addVerticalSpace(87)
  g_loadingIcon = layout:addIcon{path = g_appZip .. "loading_black_ND.img"}

  -- Loading Title
  print("creating g_loadingTitle")
  layout:addVerticalSpace(5)
  layout:indent(16)
  layout:direction(ui.LayoutDirection.VERTICAL)
  layout:hAlign(ui.LayoutHAlign.LEFT)
  g_loadingTitle = layout:addText {
     content = "Clock data", lines = 1, 
     color = g_worldColor,
     font = { size=29},
  }

  -- Loading Information
  print("creating g_loadingInfo")
  layout:addVerticalSpace(-7)
  g_loadingInfo = layout:addText {
     content = "LOADING...", lines = 1, 
     color = g_worldColor,
     font = { size=20, weight="bold"},
  }

  -- Change colors to the first state
  self:changeColors()

  print ("Constructed")

  return 0
end

function WorldClock:getMinutes(offset)
  -- Given an offset in a string from GMT convert format is "HH:MM" 
  -- convert it to a value in minutes

  local s, e = string.find(offset, ":")
  if s == nil then
    -- Not a valid string
    return 0
  end
 
  local hour = string.sub(offset, 1, e-1)
  local hours = tonumber(hour)
  if hours == nil then
     print ("getMinutes: Error hour not a number")
     hours = 0
  end

  local minute = string.sub(offset, e+1, #offset)
  local minutes = tonumber(minute)
  if minutes == nil then
     print ("getMinutes: Error minutes not a number")
     minutes = 0
  end

  return ((hours * 60) + minutes)
end

function WorldClock:getMinuteOffset(worldOffset)
  -- Calculate the difference in minutes from the current time
  -- zone to the world time zone
  local localMinutes = dt.DateTimeModel:getCurrentTimeZone()
  local worldMinutes = self:getMinutes(worldOffset)

  local minuteOffset = 0
  -- Go back to UTC from where we are
  minuteOffset = minuteOffset - localMinutes

  -- Now move to where we would like to be
  minuteOffset = minuteOffset + worldMinutes

  print ("localMinutes: " .. localMinutes)
  print ("worldMinutes: " .. worldMinutes)
  print ("minuteOffset: " .. minuteOffset)

  return minuteOffset
end

function WorldClock:getGMTOffset(worldOffset)
  local worldMinutes = self:getMinutes(worldOffset)
  print ("World TZ minutes: " .. worldMinutes)

  return worldMinutes
end

function WorldClock:updateTimeValues(timeModel)
  print("in updateTimeValues")
end

function WorldClock:updateBgImage()
  -- Determine which background image to use based on the color state
  -- and which city is currently displayed
  print ("in updateBgImage")

  local bgPath = g_appZip .. "bg_world_"
  if (#g_worldCities > 0) and 
     (g_worldCities[g_currentIndex]["name"] == g_currentCity[1]) then
    bgPath = bgPath .. "nobar_"
  end

  if g_localColor == "m_63" then
    bgPath = bgPath .. "inverse_"
  end

  bgPath = bgPath .. "ND.img"

  print ("Setting the background to: " .. bgPath)

  if g_backgroundIcon ~= nil then
     g_backgroundIcon:setProp{path = bgPath}
  end
end

function WorldClock:getLocalCityIndex()
  -- Search the list of World Cities for the index of the local city
  -- this can then be used to make sure we don't start at the local
  -- city.
  print ("in getLocalCityIndex")

  if #g_currentCity == 0 then
    -- No local city default to the last entry
    print ("No local city: ")
    return #g_worldCities
  end

  local localCityName = g_currentCity[1]
  for i = 1, #g_worldCities do
    if localCityName == g_worldCities[i]["name"] then
      return i
    end
  end

  -- Nothing found default to the last one
  print ("Could not find local city in the list")
  return #g_worldCities
end

-- Load in the weather icons
function WorldClock:loadIcons()
  print("In loadIcons")

  if #g_worldCities > 0 then

     -- ClockWorld zip data has been loaded
     local bgLetter = "B" -- White images
     if g_localColor == "m_63" then
        bgLetter = "A" -- Black images
     end
     
     local basePath = g_worldZip .. "images/" .. g_worldCities[g_currentIndex]["folderName"] 
     local tempPath = basePath .. "/temp_" .. bgLetter .. ".img"
     local iconPath = basePath .. "/icon_" .. bgLetter .. ".img"

     g_worldTemp:setProp{path = tempPath}
     g_worldWeather:setProp{path = iconPath}
  else

     -- Show the loading widgets
     local bgWord = "white"
     if g_localColor == "m_63" then
        bgWord = "black"
     end

     local loadingPath = g_appZip .. "loading_" .. bgWord .. "_ND.img"
     print ("loadingPath = " .. loadingPath) 
     g_loadingIcon:setProp{path = loadingPath}
  end
  return 0 
end

function WorldClock:setVisibility()
  -- Determine the visibility state of all the various widgets
  -- based on the state of the UI

  print ("in setVisibility")

  -- Are we in the loading state
  if self:noDataAvailable() then
     
     print ("loadingState = true")
     g_loadingIcon:setProp { visible = true }
     g_loadingTitle:setProp { visible = true }
     g_loadingInfo:setProp { visible = true }
     
     g_localCity:setProp { content = "",
                           visible = false }
     g_localTime:setProp { visible = true }
     
     g_worldCity:setProp { content = "",
                           visible = false }
     g_worldTime:setProp { visible = false } 
     g_worldAMPM:setProp { visible = false } 
     g_worldDay:setProp { visible = false }

     local currentTimeModel = dt.DateTimeModel:getCurrentTime()
     g_worldTime:setmodel(currentTimeModel)
     g_worldAMPM:setmodel(currentTimeModel)
     g_worldDay:setmodel(currentTimeModel)
     
     g_worldTemp:setProp { visible = false }
     g_worldWeather:setProp { visible = false }
  else
     
     print ("loadingState = false")
     g_loadingIcon:setProp { visible = false }
     g_loadingTitle:setProp { visible = false }
     g_loadingInfo:setProp { visible = false }
     
     -- Do we have a local city, and does the world
     -- city have the same name
     local localVisibility = true
     if #g_currentCity > 0 and
        g_currentCity[1] == g_worldCities[g_currentIndex]["name"] then
        localVisibility = false
     end
     
     print ("localVisibility = ", localVisibility)
     g_localCity:setProp { visible = localVisibility }
     g_localTime:setProp { visible = localVisibility }
     
     g_worldCity:setProp { visible = true }
     g_worldTime:setProp { visible = true } 
     g_worldAMPM:setProp { visible = true } 
     g_worldDay:setProp { visible = true } 
     
     g_worldTemp:setProp { visible = true } 
     g_worldWeather:setProp { visible = true }
  end
end

function WorldClock:noDataAvailable()
  print ("in noDataAvailable")

  -- Determine if we have any data available to show
  if #g_worldCities == 0 then
    print ("no world cities")
    return true
  end

  for i=1, #g_worldCities do
    if g_worldCities[i]["gmtOffset"] == "null" then
      print ("data connection down: gmtOffset = null" .. " " .. g_worldCities[i]["name"] )
      return true
    end
  end

  return false
end


function WorldClock:changeColors()
  print("In changeColors: " .. g_localColor .. " " .. g_worldColor)
  
  if g_localColor == "m_0" then
    g_localColor = "m_63"
    g_worldColor = "m_0"
  else
    g_localColor = "m_0"
    g_worldColor = "m_63"
  end

  print("In changeColors: " .. g_localColor .. " " .. g_worldColor)

  -- Update all the widgets to the new values
  g_localCity:setProp{ color = g_localColor }
  g_localTime:setProp{ color = g_localColor }

  g_worldCity:setProp{ color = g_worldColor }
  g_worldTime:setProp{ color = g_worldColor }
  g_worldAMPM:setProp{ color = g_worldColor }
  g_worldDay:setProp{ color = g_worldColor }

  g_loadingTitle:setProp{ color = g_worldColor }
  g_loadingInfo:setProp{ color = g_worldColor }

  self:loadImages()
end

function WorldClock:loadImages()
  self:updateBgImage()
  self:loadIcons()
  return 0
end

function WorldClock:hideLocal()

  -- Setup the display so that we hide the local city name
  -- if it is the same as the world city
  g_localCity:setProp { visible = hideLocal }
  g_localTime:setProp { visible = hideLocal }

end

function WorldClock:getBackgroundIndex()
  print("In getBackgroundIndex")
  if g_localColor == "m_0" then
    return 0
  end
  
  return 1
end

function WorldClock:onTap()
  print("In onTap")

  if #g_worldCities < 2 then
     -- Nothing to do
     print ("Nothing to do: #g_worldCities = ", #g_worldCities)
     return
  end

  self:gotoNextCity()
  return 0
end

function WorldClock:gotoNextCity()
  -- Move to the next city in the list and update
  -- the name and time zone for that city
  print("In gotoNextCity")

  -- Increment the current city
  g_currentIndex = g_currentIndex + 1
  if g_currentIndex > #g_worldCities then
     g_currentIndex = 1
  end

  local worldCityName = g_worldCities[g_currentIndex]["name"]
  print ("worldCity name : " .. worldCityName)
  g_worldCity:setProp { content = worldCityName }

  -- Determine the tz offset
  local minuteOffset = self:getGMTOffset(g_worldCities[g_currentIndex]["gmtOffset"])

  -- Reset the time models, default DST for now
  local dstMinutes = 0
  local worldTimeModel = dt.DateTimeModel:getCurrentTime(minuteOffset, dstMinutes)

  g_worldTime:setmodel(worldTimeModel)
  g_worldAMPM:setmodel(worldTimeModel)
  g_worldDay:setmodel(worldTimeModel)

  self:loadImages()
  self:setVisibility()
end

-- 
-- currentCity
function currentCity (t)
  g_currentCity = t

  if g_currentCity == nil then
    g_currentCity = {}
 end

end

-- 
-- worldCities
function worldCities (t)
  g_worldCities = t

  if g_worldCities == nil then
    g_worldCities = {}
 end

end

--
-- runCitiesFile: Utility function.
function runCitiesFile(path)
  print("in runCitiesFile: " .. path)

  -- Clear everything out, before loading the new data
  g_currentCity = {}
  g_worldCities = {}

  f, err = loadfile(path)
  if not f then
    print("Error in running " .. path .. ": " .. err .. "\n")
  else
     setfenv(f, { currentCity = currentCity, 
                  worldCities = worldCities } )
    f()
  end
end

function citiesUpdated()
  print("in citiesUpdated")
  runCitiesFile(g_worldZip .. "cities.dat")

  if (#g_worldCities == 0) then
    -- We did not receive any valid data
    print ("cities.dat contained no valid world city data")
    g_wClock:setVisibility()
    return
  end

  local currentCityName = ""
  if #g_currentCity == 1 then
    -- Should we revise this to not be a table?
    currentCityName = g_currentCity[1]
    print ("currentCity: " .. currentCityName)
  else
    print ("cities.dat contained no current city data")
  end

  g_localCity:setProp {
    content = currentCityName
  }

  -- refresh the screen with new data
  g_currentIndex = g_wClock:getLocalCityIndex()

  -- gotoNextCity will increment the index first so we don't start on the
  -- local city
  g_wClock:gotoNextCity()
end

--
-- The clock we are going to return 
g_wClock = nil

CitiesMonitor = oo.class("CitiesMonitor", platform.FMSMonitor)

function CitiesMonitor:onUpdate(path)
  citiesUpdated()
  return 0
end

function CitiesMonitor:onDelete(path)
  citiesUpdated()
  return 0
end

function CitiesMonitor:onParentDelete(path)
  citiesUpdated()
  return 0
end

-- 
-- startClock: The main entry point to the clock, returns a clock object
--
function newClock ()
  print ("Calling newClock")
  g_wClock = WorldClock()

  if not g_fmsCities then   -- register once
    g_fmsCities = assert(CitiesMonitor {path = "fms:/ClockWorld.zip"},
                         "FMS monitor failed")
  end

  if g_wClock ~= nil then
    -- Load up any existing ClockWorld.zip data
    citiesUpdated()
  end

  return g_wClock
end

-- This is the table of all entry points into the clock
ClockEntries = {
  createclock = newClock
}

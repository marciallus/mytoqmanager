-- =============================================================================
--      Copyright (c) 2013-2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
-- ==============================================================================

----------------------
-- Global variables --
----------------------

oo = require "oo"   -- get the Object Oriented library
ui = require "ui"   -- get the UI library
dt = require "datetime"

--The Tile Clock class overrides the built-in Clock class
TileClock = oo.class("TileClock", ui.Clock)

-- Base part of zip files

function TileClock:construct()
  print ("in construct")

  local layout = ui.Layout(self)

  -- draw the icon
  self.appZip = "fms:/app.zip?"
  local imagePath = self.appZip .. "background_inverse_ND.img"
  print (imagePath)
  self.backgroundIcon = layout:addIcon{path = imagePath}

  -- reset 
  layout:resetGeometry()
  layout:direction(ui.LayoutDirection.HORIZONTAL)

  -- Default starting time to initilaise the digits
  self.hour = "12"
  self.minutes = "59"

  -- We just need to get the Y positions correct as we will adjust
  -- the X position when we know what numbers we actually have

  -- Hour Digit 1
  imagePath = self.appZip .. "digit_1_inverse_ND.img"
  print (imagePath)
  layout:addVerticalSpace(55)
  self.hourIcon1 = layout:addIcon{path = imagePath}

  -- Hour Digit 2
  layout:addVerticalSpace(-12) -- 43
  imagePath = self.appZip .. "digit_2_inverse_ND.img"
  print (imagePath)
  self.hourIcon2 = layout:addIcon{path = imagePath}

  -- Colon
  layout:addVerticalSpace(10)   -- 53
  imagePath = self.appZip .. "digit_colon_inverse_ND.img"
  print (imagePath)
  self.colonIcon = layout:addIcon{path = imagePath}

  -- Minute Digit 1
  layout:addVerticalSpace(-11) -- 42
  imagePath = self.appZip .. "digit_5_inverse_ND.img"
  print (imagePath)
  self.minuteIcon1 = layout:addIcon{path = imagePath}

  -- Minute Digit 2
  layout:addVerticalSpace(11) -- 53
  imagePath = self.appZip .. "digit_9_inverse_ND.img"
  print (imagePath)
  self.minuteIcon2 = layout:addIcon{path = imagePath}

  self.inverse = true
  --[[
  self.hardcode = 1
  --]]

  -- Change colors to the first state
  self:changeColors()

  print ("Constructed")

  return 0
end

function TileClock:updateTimeValues(timeModel)
  print("in updateTimeValues")
  -- %I drops the leading zero, differs from strftime
  self.hour = timeModel:getTimeString("%I")
  self.minutes = timeModel:getTimeString("%M")

  --[[
  if self.hardcode == 1 then
     self.hour = "11"
     self.minutes = "50"
     self.hardcode = 2
  elseif self.hardcode == 2 then
     self.hour = "1"
     self.minutes = "59"
     self.hardcode = 3
  else
     self.hour = "11"
     self.minutes = "12"
     self.hardcode = 1
  end
  --]]

  print ("hour = " .. self.hour) 
  print ("minutes = " .. self.minutes)
  self:loadImages()
end

function TileClock:changeColors()
  print("In changeColors: " .. tostring(self.inverse))

  if self.inverse == false then
     self.inverse = true
  else
     self.inverse = false
  end

  self:loadImages()
end

function TileClock:loadImages()
  print ("In loading images")

  local basePath = self.appZip .. "digit_"
  local dotImg = "_ND.img"
  if not self.inverse then
    dotImg = "_inverse_ND.img"
  end

  local hourPath = basePath .. self.hour:sub(1, 1) .. dotImg
  if self:threeDigits() then
    self.hourIcon1:setProp{ visible = false }
  else
    self.hourIcon1:setProp{path = hourPath, visible = true }
    hourPath = basePath .. self.hour:sub(2, 2) .. dotImg
  end
  self.hourIcon2:setProp{path = hourPath}

  local m1Path = basePath .. self.minutes:sub(1, 1) .. dotImg
  local m2Path = basePath .. self.minutes:sub(2, 2) .. dotImg
  self.minuteIcon1:setProp{path = m1Path}
  self.minuteIcon2:setProp{path = m2Path}

  local colonPath = self.appZip .. "digit_colon" .. dotImg
  self.colonIcon:setProp{path = colonPath}

  local bgPath = self.appZip .. "background" .. dotImg
  self.backgroundIcon:setProp{path = bgPath}

  self:adjustPositions()

  print ("Images loaded")
  return 0
end

function TileClock:threeDigits()
  local rval = false

  if #self.hour == 1 then
    rval = true
  end

  return rval
end

function TileClock:getWidth(coords)
  if coords == nil then
    print ("nil coords passed to getWidth()")
    return 0
  end

  width = coords.right - coords.left + 1
  return width
end

function TileClock:getDigitsWidth(threeDigits)
  -- Calculates the width of all the digits shown
  local totalWidth = self:getWidth(self.hourIcon2:getCoords())
  totalWidth = totalWidth + self:getWidth(self.colonIcon:getCoords())
  totalWidth = totalWidth + self:getWidth(self.minuteIcon1:getCoords())
  totalWidth = totalWidth + self:getWidth(self.minuteIcon2:getCoords())

  local spaces = 3
  if not threeDigits then
    totalWidth = totalWidth + self:getWidth(self.hourIcon1:getCoords())
    spaces = 4
  end

  -- Add in the spaces
  totalWidth = totalWidth + spaces
  return totalWidth
  end

function TileClock:moveIcon(x, icon)
  local coords = icon:getCoords()
  icon:move(x, coords.top)
  coords = icon:getCoords()
  return coords.right + 1
end

function TileClock:adjustPositions()
  -- Move the images around so that they are all placed in their ideal position
  -- Find our starting point
  -- Which is (parentW - imageW)/2 then draw everyhing from the left
  local parentCoords = self:getCoords()
  local parentWidth = self:getWidth(parentCoords)
  local threeDigits = self:threeDigits()
  local digitsWidth = self:getDigitsWidth(threeDigits)
  local x = parentCoords.left + math.floor((parentWidth - digitsWidth)/2)

  if not threeDigits then
    x = self:moveIcon(x, self.hourIcon1)
  end

  x = self:moveIcon(x, self.hourIcon2)
  x = self:moveIcon(x, self.colonIcon)
  x = self:moveIcon(x, self.minuteIcon1)
  x = self:moveIcon(x, self.minuteIcon2)
end

--
-- The clock we are going to return 
g_tileClock = nil

-- 
-- startClock: The main entry point to the clock, returns a clock object
--
function newClock ()
  print ("Calling newClock")
  g_tileClock = TileClock()

  return g_tileClock
end

-- This is the table of all entry points into the clock
ClockEntries = {
  createclock = newClock
}

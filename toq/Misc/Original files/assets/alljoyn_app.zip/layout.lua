--==============================================================================
--      Copyright (c) 2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
--==============================================================================

oo = require "oo"   -- get the Object Oriented library
ui = require "ui"   -- get the UI library

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-- DeviceLayoutPicklist class --
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
DeviceLayoutPicklist = oo.class("DeviceLayoutPicklist", ui.Button)
DeviceLayoutPicklist.Listing = oo.class("DeviceLayoutPicklist.Listing", ui.List)
DeviceLayoutPicklist.Panel = oo.class("DeviceLayoutPicklist.Panel", ui.Panel)

function DeviceLayoutPicklist.Listing:init(params, parent)
  self.__parent = parent  -- it is necessary to set the __parent before invoking
                          -- super class. As list widget seem to invoke the
                          -- virtual methods from superclass construction.
  DeviceLayoutPicklist.Listing:superClass().init(self, params)
end

---------------------------------------------------------------------------------
function DeviceLayoutPicklist.Listing:onItemHeight(index)
  return 68  -- TODO: make this optional override
end

---------------------------------------------------------------------------------
function DeviceLayoutPicklist.Listing:onItemSelected(pos)
  local me = self.__parent   -- the instance of DeviceLayoutPicklist
  local lp = me.picklist     -- the picklist contents directive

  pos = pos + 1    -- list provides a 0 indx for starting.
  print("DeviceLayoutPicklist.Listing:onItemSelected : " .. pos)
  if pos == lp.current then   -- no action to take
    return
  end

  -- remove the old prompt
  if me.prompt then
    me.prompt:destroy()
    me.prompt = nil
  end

  -- remove the old selected icon
  if nil ~= me.selectedIcon then
    me.selectedIcon:destroy()
    me.selectedIcon = nil
  end

  lp.current = pos    -- update the current item

  -- add new selected icon
  local l = ui.Layout(me.optionCards[lp.current])
  l:indent(0, 3)
  l:vAlign(ui.LayoutVAlign.CENTER)
  l:hAlign(ui.LayoutHAlign.RIGHT)
  me.selectedIcon = l:addIcon {path = "fms:/app.zip?check_ND.img"}

  -- add new prompt
  local l = ui.Layout(me)
  l:indent(11, 11)
  l:addVerticalSpace(9)
  l:hAlign(ui.LayoutHAlign.CENTER)
  l:vAlign(ui.LayoutVAlign.CENTER)
  l:setConstrainedWidth(230)
  me.prompt = l:addText{
    content = lp.options[lp.current], lines = 2, color = "m_0", 
    font = {size = 29}
  }

  sendEvent(me.id, "changed", pos)
end

---------------------------------------------------------------------------------
function DeviceLayoutPicklist.Listing:onNewItem(posrect, index)
  local me = self.__parent   -- the instance of DeviceLayoutPicklist
  local lp = me.picklist     -- the picklist contents directive
  
  print("DeviceLayoutPicklist.Listing:onNewItem")
  local myCard = ui.Card { 
    left = posrect.left, right = posrect.right,
    top = posrect.top, bottom = posrect.bottom,
    pos = index, idx = index + 1 }

  local cl = ui.Layout(myCard)
  cl:addVerticalSpace(9)
  cl:indent(15, 6)
  cl:direction(ui.LayoutDirection.HORIZONTAL)
  cl:hAlign(ui.LayoutHAlign.LEFT)
  cl:vAlign(ui.LayoutVAlign.CENTER)
  cl:setConstrainedWidth(220)
  cl:addText{
    content = lp.options[index+1], lines = 2, color = "m_0", 
    font = {size = 29}
  }
  cl:clearConstrainedWidth()

  if lp.current == (index+1) then
    cl:resetGeometry()
    cl:indent(0, 3)
    cl:hAlign(ui.LayoutHAlign.RIGHT)
    me.selectedIcon = cl:addIcon {
      path = "fms:/app.zip?check_ND.img"
    }
  end

  me.optionCards[index + 1] = myCard

  return myCard
end

---------------------------------------------------------------------------------
function DeviceLayoutPicklist.Panel:init(params, parent)
  DeviceLayoutPicklist.Panel:superClass().init(self, params)
  self.__parent = parent
end

---------------------------------------------------------------------------------
function DeviceLayoutPicklist.Panel:onClose()
  local me = self.__parent   -- the instance of DeviceLayoutPicklist
  
  print("DeviceLayoutPicklist.Panel:onClose")
  for k, v in pairs(me.optionCards) do
    me.optionCards[k] = nil
  end
  me.selectedIcon = nil
  me.listing      = nil
  me.view         = nil
end

---------------------------------------------------------------------------------
function DeviceLayoutPicklist:init(picklist, id)
  DeviceLayoutPicklist:superClass().init(self, {width = 266, height = 68})
  self.id = id
  self.prompt = nil                -- prompt in the button
  self.picklist = picklist         -- the picklist contents directive

  self.optionCards = {}            -- cards listing
  self.selectedIcon = nil          -- selected icon used in the cards listing
  self.listing = nil               -- listing widget in the panel
  self.view = nil                  -- panel view

  local l = ui.Layout(self)
  
  l:indent(11, 11)
  l:addVerticalSpace(9)
  l:direction(ui.LayoutDirection.HORIZONTAL)
  l:hAlign(ui.LayoutHAlign.CENTER)
  l:vAlign(ui.LayoutVAlign.CENTER)
  l:setConstrainedWidth(230)
  self.prompt = l:addText{
    content = picklist.options[picklist.current], lines = 2, color = "m_0", 
    font = {size = 29}
  }
  l:clearConstrainedWidth()

  l:hAlign(ui.LayoutHAlign.RIGHT)
  l:addIcon {path = "fms:/app.zip?alljoyn_arrow.img"}
end

---------------------------------------------------------------------------------
function DeviceLayoutPicklist:onClick()
  local lp = self.picklist     -- the picklist contents directive

  -- create a panel
  self.view = DeviceLayoutPicklist.Panel({ color = "m_27" }, self)

  -- widget for item listing
  self.listing = DeviceLayoutPicklist.Listing( 
    {left = 8, top = 0, bottom = 191, right = 287, 
      numitems = #lp.options, itemheight = 68}, self) 
  self.view:add(self.listing, true)

  print("DeviceLayoutPicklist.Listing instantiated")
  print(self.listing)

  -- bring the view to foreground
  self.view:show()
end


---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-- DeviceLayoutSlider class --
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
DeviceLayoutSlider = oo.class("DeviceLayoutSlider")
DeviceLayoutSlider.Button = oo.class("DeviceLayoutSlider.Button", ui.Button)

function DeviceLayoutSlider.Button:init(params, parent, eventdata)
  DeviceLayoutSlider.Button:superClass().init(self, params)
  self.__parent = parent
  self.eventdata = eventdata
end

---------------------------------------------------------------------------------
-- send slider events
function DeviceLayoutSlider.Button:onClick()
  local me = self.__parent
  sendEvent(me.id, self.eventdata)
end

---------------------------------------------------------------------------------
function DeviceLayoutSlider:init(id)
  self.id = id
  self.bplus = DeviceLayoutSlider.Button({
    normal = "fms:/app.zip?plus_ND.img", 
    touched = "fms:/app.zip?plus_t_ND.img",}, self, "up")

  self.bminus = DeviceLayoutSlider.Button({
    normal = "fms:/app.zip?minus_ND.img", 
    touched = "fms:/app.zip?minus_t_ND.img",}, self, "down")
end

---------------------------------------------------------------------------------
-- use another layout instance on the container, move to the offset and
-- add both the buttons.
function DeviceLayoutSlider:addTo(offset, container)
  local l = ui.Layout(container)
  l:direction(ui.LayoutDirection.HORIZONTAL)
  l:addVerticalSpace(offset.y)
  l:indent(offset.x, 0)
  l:appendWidget(self.bminus)
  l:indent(30, 0)
  l:appendWidget(self.bplus)
  return l:width()
end

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-- DeviceLayoutButton class --
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
DeviceLayoutButton = oo.class("DeviceLayoutButton", ui.Button)

function DeviceLayoutButton:init(params, id)
  DeviceLayoutButton:superClass().init(self, params)
  self.id = id
end

---------------------------------------------------------------------------------
function DeviceLayoutButton:onClick()
  print("DeviceLayoutButton:OnClick() id:" .. self.id)
  sendEvent(self.id, "clicked")
  DeviceLayoutButton:superClass().onClick()
end

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-- DeviceLayout class --
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
DeviceLayout = oo.class("DeviceLayout", ui.Layout)

function DeviceLayout:init(widget)
  DeviceLayout:superClass().init(self, widget)
  self.widget = widget
  self.direction_ = ui.LayoutDirection.HORIZONTAL -- local copy initialized to
                    -- same value as the underlying instance of wd_LayoutManager
end

---------------------------------------------------------------------------------
function DeviceLayout:applyLayout(lt)
  if lt.direction then
    self.direction_ = lt.direction   -- keep a copy of current direction.
    self:direction(lt.direction)
  end
  if lt.indent then
    self:indent(lt.indent[1], lt.indent[2])
  end
  if lt.addverticalspace then
    self:addVerticalSpace(lt.addverticalspace)
  end
  if lt.halign then
    self:hAlign(lt.halign)
  end
  if lt.valign then
    self:vAlign(lt.valign)
  end
  if lt.setconstrainedwidth then
    self:setConstrainedWidth(lt.setconstrainedwidth)
  end
  if lt.clearconstrainedwidth then
    self:clearConstrainedWidth()
  end
  if lt.setconstrainedheight then
    self:setConstrainedHeight(lt.setconstrainedheight)
  end
  if lt.clearconstrainedheight then
    self:clearConstrainedHeight()
  end
  if lt.fillcolor then
    self.widget:setProp { background = lt.fillcolor }
  end
end

---------------------------------------------------------------------------------
function DeviceLayout:addIcon(ic)
  return DeviceLayout:superClass().addIcon(self, {path = ic.path, 
                                                  altpath = ic.altpath})
end

---------------------------------------------------------------------------------
function DeviceLayout:addButton(btn, id)
  local b = DeviceLayoutButton({width = btn.width, height = btn.height},
                               id)
  self:appendWidget(b)
  return b
end

---------------------------------------------------------------------------------
function DeviceLayout:addSlider(s, id)
  local slider = DeviceLayoutSlider(id)
  local w = slider:addTo({x = self:width(), y = self:height()}, self.widget)

  -- adjust the position for next widget
  if self.direction_ == ui.LayoutDirection.VERTICAL then
    self:addVerticalSpace(76)  -- the height of slider button
  else
    self:indent(w, 0)  -- indent by the width of slider
  end
end

---------------------------------------------------------------------------------
function DeviceLayout:addPicklist(p, id)
  local picklist = DeviceLayoutPicklist(p, id)
  self:appendWidget(picklist)
end

---------------------------------------------------------------------------------
function DeviceLayout:addContents(cont)
  -- iterate over contents table. 
  for i, w in ipairs(cont) do 
    if w.type == "text" then
      self:addText(w.text)
    elseif w.type == "icon" then
      self:addIcon(w.icon)
    elseif w.type == "layout" then
      self:applyLayout(w.layout)
    elseif w.type == "button" then
      local b = self:addButton(w.button, w.id)
      local l = DeviceLayout(b)
      l:addContents(w.button.contents)
    elseif w.type == "slider" then
      self:addSlider(w.slider, w.id)
    elseif w.type == "picklist" then
      self:addPicklist(w.picklist, w.id)
    end
  end
end

return DeviceLayout


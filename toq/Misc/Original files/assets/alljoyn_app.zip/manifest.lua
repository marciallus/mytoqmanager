-- ============================================================
--    Copyright (c) 2014 Qualcomm Connected Experiences, Inc   
--                     All Rights Reserved                     
--             Qualcomm Connected Experiences, Inc             
-- ============================================================

app {
  name = "AllJoyn",
  username = "AllJoyn",
  icon_white = "fms:/app.zip?appicon_white_ND.img",
  icon_color = "fms:/app.zip?appicon_color_ND.img",
  entrypoints = "AlljoynApp",
}

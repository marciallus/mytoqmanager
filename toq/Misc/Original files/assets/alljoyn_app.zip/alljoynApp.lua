--==============================================================================
--      Copyright (c) 2013 - 2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
--==============================================================================

---------------------------------------------------------------------------------
-- Global variables--
---------------------------------------------------------------------------------
oo = require "oo"   -- get the Object Oriented library
ui = require "ui"   -- get the UI library
platform = require "platform" -- get the fms package
DeviceLayout = require "layout"
local i18n = require "i18n"

-- This is where all the device info (from devices.dat) is stored
g_deviceCards = {}
g_deviceCount = 0

-- main panel returned when app is started
g_mainPanel = nil

-- a listener handle on fms:/devices.dat
g_devicesFmsMonitor = nil

-- devices currently open.
g_opened_devices = {}

-- This is where all the popup cards are stored, indexed by card.id.
-- value is an array {card, panel, scrollable}
g_popupCards = {}

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-- AlljoynApp : This is the table of all entry points into the app
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
AlljoynApp = {}

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-- DeviceList class --
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
DeviceList = oo.class("DeviceList", ui.List)

function DeviceList:onItemSelected(pos)
  print("DeviceList:onItemSelected : " .. g_deviceCards[pos+1].name)
  showDevice(g_deviceCards[pos+1])
end

function DeviceList:onNewItem(posrect, index)
  print("DeviceList:onNewItem : " .. index)
  card, h = createNewCard(posrect, index)
  return card
end

function DeviceList:onItemHeight(index)
  print("DeviceList:onItemHeight : " .. index)
  if index < g_deviceCount then
    local l_rect = { left = 0, top = 0, bottom = 191, right = 287, }
    local h  -- height of the card
    local card -- the card widget, which we need to destroy here
    card, h = createNewCard(l_rect, index)
    card:destroy()
    return h
  else
    return nil
  end
end


---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-- MainPanel class --
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
MainPanel = oo.class("MainPanel", ui.Panel)

function MainPanel:init(params)
  MainPanel:superClass().init(self, params)
  self.cardList = nil          -- listing view of devices

  -- message prompts used when there are no devices found
  self.noCardsPrompt = nil
  self.helpMessage = nil
end

---------------------------------------------------------------------------------
-- Is called to remove no devices found message.
-- idempotent kind
function MainPanel:removeEmptyPrompt()
  if self.noCardsPrompt then
     self.noCardsPrompt:destroy()
     self.noCardsPrompt = nil
  end
  if self.helpMessage then
     self.helpMessage:destroy()
     self.helpMessage = nil
  end
end

---------------------------------------------------------------------------------
function MainPanel:addEmptyPrompt()
  self:removeEmptyPrompt()  -- idempotent

  self:setProp{ background = "m_63" }  -- change background to white

  -- add text strings
  local panelLayout = ui.Layout(self)
  panelLayout:addVerticalSpace(19)
  panelLayout:indent(19, 19)
  self.noCardsPrompt = panelLayout:addText {
    content = i18n"NO DEVICES FOUND", 
    lines = 2, color = "m_3",
    font = { size = 20, weight = "bold"}
  }

  panelLayout:resetGeometry()
  panelLayout:addVerticalSpace(70)
  panelLayout:indent(19, 19)
  self.helpMessage = panelLayout:addText {
    content = i18n"Alljoyn supporting devices have not been found.", 
    lines = 0, color = "m_0",
    font = { size = 26 }
  }
end

---------------------------------------------------------------------------------
-- This constructs the main view of the app
function MainPanel:populate()
  if g_deviceCount == 0 then
    -- If there was an existing list of cards, need to remove it from panel and
    -- dtor it
    if self.cardList then
      self.cardList:destroy()
      self.cardList = nil
    end

    self:addEmptyPrompt()
    return
  end

  if self.cardList then
    -- In the case where there are cards available, and a previous 
    -- cardlist exists we can simply reset the cardlist to repopulate it
    print("CardList resizing. For " .. g_deviceCount .. " devices.")
    self.cardList:reset(g_deviceCount)
    return
  end

  -- Remove the nocardsprompt from the panel if its there
  self:removeEmptyPrompt()

  self:setProp{ background = "m_27" }  -- change background to 27

  print("DeviceList created. For " .. g_deviceCount .. " devices.")
  -- If no previous cardlist, then create one and add to panel
  self.cardList = assert(DeviceList{left = 0, top = 0, bottom = 191, right = 287,
                                    numitems = g_deviceCount, itemheight = 160 },
                         "Card list creation failed")

  self:add(self.cardList, true)  -- relative to the container
end

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-- DevicePanel class --
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
DevicePanel = oo.class("DevicePanel", ui.Panel)

function DevicePanel:init(device)
  DevicePanel:superClass().init(self, {})
  self.device = device
  self.scrollable = ui.Scrollable {
    left = 0, top = 0, right = 287, bottom = 191
  }
  self:add(self.scrollable, true)
end

---------------------------------------------------------------------------------
function DevicePanel:onClose()
  -- remove the reference from openeddevices
  g_opened_devices[self.device.id] = nil
  sendEvent(self.device.id, "closed")
  DevicePanel:superClass().onClose(self)
end

---------------------------------------------------------------------------------
function DevicePanel:onFocus()
  sendEvent(self.device.id, "visible")
  DevicePanel:superClass().onFocus(self)
end

---------------------------------------------------------------------------------
function DevicePanel:onDefocus()
  sendEvent(self.device.id, "invisible")
  DevicePanel:superClass().onDefocus(self)
end

---------------------------------------------------------------------------------
function DevicePanel:drawContents()
  local l = DeviceLayout(self.scrollable)

  if self.device and self.device.contents then
    l:addContents(self.device.contents)
  else
    -- empty device contents message.
    l:direction(ui.LayoutDirection.VERTICAL)
    l:addVerticalSpace(19)
    l:indent(19, 19)
    l:addText {
      content = i18n"DEVICE UNAVAILABLE",
      lines = 2, color = "m_3",
      font = { size = 20, weight = "bold" }
    }

    l:addVerticalSpace(25)
    l:addText {
      content = i18n"Check the device is powered ON and connected to Alljoyn service", 
      lines = 0, color = "m_0",
      font = { size = 26 }
    }
  end

  sendEvent(self.device.id, "opened")
end

---------------------------------------------------------------------------------
function DevicePanel:updateContents(device)
  self.device = device
  self.scrollable:destroy()
  self.scrollable = ui.Scrollable {
    left = 0, top = 0, right = 287, bottom = 191
  }
  self:add(self.scrollable, true)
  self:drawContents()
end

---------------------------------------------------------------------------------
-- Functions --
---------------------------------------------------------------------------------

---------------------------------------------------------------------------------
function sendEvent(id, evt, evtdata)
  local contentmsg = "Event { \n"
  contentmsg = contentmsg .. "id = \"" .. id .. "\",\n"
  contentmsg = contentmsg .. "event = \"" .. evt .. "\",\n"
  if evtdata then
    contentmsg = contentmsg .. "data = \"" .. evtdata .. "\",\n"
  end
  contentmsg = contentmsg .. "}\n"
  sendmessage(contentmsg)
end

---------------------------------------------------------------------------------
function showDevice(targetdevice)

  print("Create device contents [" .. targetdevice.name .. "]")

  local p = DevicePanel(targetdevice)
  
  -- add the information to opened_devices
  g_opened_devices[targetdevice.id] = p

  p:drawContents()
  -- show the panel and contents
  p:show()

  -- send event to peer app the identfied device is now open.
  sendEvent(targetdevice.id, "opened")
end

---------------------------------------------------------------------------------
-- create a new card for the given rectangle and using the card index to the
-- model.
function createNewCard(posrect, index)
  if index < g_deviceCount then
    local mycard = ui.Card { 
      left = posrect.left, right = posrect.right,
      top = posrect.top, bottom = posrect.top + 11 + 58 + 11,
      pos = index, idx = index + 1 
    }
    local cardLayout = ui.Layout(mycard)
    cardLayout:addVerticalSpace(11)
    cardLayout:indent(9)
    cardLayout:direction(ui.LayoutDirection.HORIZONTAL)
    cardLayout:hAlign(ui.LayoutHAlign.LEFT)

    local iconpath = "fms:/app.zip?alljoyn_58_ND.img"
    if g_deviceCards[index+1].icon ~= nil then
      iconpath = g_deviceCards[index+1].icon
    end

    cardLayout:addIcon {
      path = iconpath,
      altpath = "fms:/app.zip?alljoyn_58_ND.img"
    }

    cardLayout:indent(8, 9)   -- 8 pixel gap between icon and text
    cardLayout:vAlign(ui.LayoutVAlign.CENTER)
    cardLayout:addText {
      content = g_deviceCards[index+1].name, lines = 2, color = "m_0",
      font = { size = 29 }
    }

    return mycard, 58 + 22
  else
    return nil
  end
end

---------------------------------------------------------------------------------
-- reads the devices.dat file from fms
function readDevices()
  local path
  local f, err

  path = "fms:/devices.dat"
  f, err = loadfile(path)
  if not f then
    print("Error reading " .. path .. " : " .. err .. "\n")
  else
    setfenv(f, getfenv(2))  -- inherit the current environment
    f()
  end
end

---------------------------------------------------------------------------------
-- This function is called by each notification entry in devices.dat
function Device(card)
  g_deviceCount = g_deviceCount + 1
  g_deviceCards[g_deviceCount] = card
  g_deviceCards[card.id] = card
end

---------------------------------------------------------------------------------
-- read and initialize mainpanel with the data from devices.dat
function initDevices()
  g_deviceCards = {}
  g_deviceCount = 0
  readDevices()
  g_mainPanel:populate()
end

---------------------------------------------------------------------------------
-- Is called in response to fms file devices.dat being updated
function devicesUpdated(file)
  print("Devices updated")
  initDevices()   -- re-initialize cards

  for k, v in pairs(g_opened_devices) do
    v:updateContents(g_deviceCards[k])
  end
end

DevicesMonitor = oo.class("DevicesMonitor", platform.FMSMonitor)

function DevicesMonitor:onUpdate(path)
  devicesUpdated(path)
  return 0
end

function DevicesMonitor:onDelete(path)
  devicesUpdated(path)
  return 0
end

function DevicesMonitor:onParentDelete(path)
  devicesUpdated(path);
  return 0
end
---------------------------------------------------------------------------------
-- The main entry point to the app. Can optionally return a panel
function AlljoynApp:onStart()
  i18n.setLocale(platform.getCurrentLocale())
  if nil == g_mainPanel then   -- create once
    g_mainPanel = assert(MainPanel({color = "m_27"}),
                         "Main panel creation failed")
  end

  initDevices()

  if not g_devicesFmsMonitor then
    g_devicesFmsMonitor = DevicesMonitor {
      path = "fms:/devices.dat"
    }
  end

  return g_mainPanel
end

---------------------------------------------------------------------------------
-- Invoked before finalizing the application instance
function AlljoynApp:onStop()
  if g_devicesFmsMonitor then
    g_devicesFmsMonitor:destroy()
    g_devicesFmsMonitor = nil
  end
end

---------------------------------------------------------------------------------
-- populateNotification: Populates the actual scrollable panel with the
-- contents of the passed in card
function populateNotification(scrollable, card)
  local l = ui.Layout(scrollable)
  l:addVerticalSpace(9)
  l:direction(ui.LayoutDirection.VERTICAL)
  l:indent(6, 6)
  l:hAlign(ui.LayoutHAlign.RIGHT)

  local iconpath = card.icon or "fms:/app.zip?small.img"

  l:addIcon{path = iconpath, altpath = "fms:/app.zip?small.img"}

  l:addVerticalSpace(-42)
  l:indent(17, 53)
  l:hAlign(ui.LayoutHAlign.LEFT)

  l:addText{content = card.app, lines = 1, color = "m_48", font = { size = 29 }}
  l:addDateTime {
     -- the notifycard/popupcard comes with time in millis, convert to seconds
     -- We are ok with truncating the value rather than rounding it
    value = card.time / 1000,
    format="%#b %d, %I:%M %p", relativeFormat="%#q %I:%M %p",
    color = "m_3",
    font = { size = 20, weight = "bold" }
  }

  l:indent(0, -51)
  l:addVerticalSpace(10)
  l:addText { content = card.title, lines = 1, color = "m_0", 
    font = { size = 24, weight = "bold" }
  }
  l:addVerticalSpace(3)

  for i, v in ipairs(card.detail) do
    l:addText {content = v, color = "m_0", font = { size = 26 }}
  end

  l:addVerticalSpace(5)
end

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-- The NotificationPanel class is used to show the details of a specific card. 
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
NotificationPanel = oo.class("NotificationPanel", ui.Panel)

function NotificationPanel:init(card)
  NotificationPanel:superClass().init(self, {})
  self.card = card
end

function NotificationPanel:onClose()
  -- remove the reference from popCards
  g_popupCards[self.card.id] = nil
  NotificationPanel:superClass().onClose(self)
end

---------------------------------------------------------------------------------
-- Given a card check if the vibe is to be suppressed
function isVibeSuppressed(card)
if card.suppressvibe and card.suppressvibe == "true" then
  return true
  end
  return false
end

---------------------------------------------------------------------------------
-- PopupCard Handle App Directed message 
function PopupCard(card)
local panel
local scrollable
  print("PopupCard for card id " .. card.id)

  -- doesn't exist on the display; create the panel and scrollable
  if not g_popupCards[card.id] then
    panel = NotificationPanel(card)
  else
    _, panel, scrollable = unpack(g_popupCards[card.id])

    -- Remove and destroy this scrollable from the panel, 
    -- we are creating a new one
    scrollable:destroy()
  end

  scrollable = ui.Scrollable {
    left = 0, top = 0, right = 287, bottom = 191
  }
  panel:add(scrollable, true)  -- true == relative to container
  g_popupCards[card.id] = {card, panel, scrollable}

  --
  populateNotification(scrollable, card)

  -- Push panel onto screen
  panel:show(true)   -- suppress panel transition

  -- donot vibe if suppressed
  if not isVibeSuppressed(card) then
    devicemgr.set_vibe(devicemgr_vibe.short)
  end

  -- activate touch
  devicemgr.activate_touch(devicemgr_touch_activity.notification)
end

---------------------------------------------------------------------------------
-- DeleteCard Handle App Directed message 
function DeleteCard(card)
  print("DeleteCard for card id " .. card.id)
  if g_popupCards[card.id] then
    print("DeleteCard: Found card")
    local panel = g_popupCards[card.id][2]

    -- just dismiss panel; this key and value are cleared in 
    -- NotificationPanel::OnClose()
    panel:dismiss()
  else
    print("DeleteCard: Not found")
  end
end

---------------------------------------------------------------------------------
-- handle message directed to this app
function AlljoynApp:onMessage(messagefunc)
  messagefunc()  -- run the chunk
  return false
end


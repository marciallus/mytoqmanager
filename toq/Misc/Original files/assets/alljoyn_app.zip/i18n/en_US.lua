--=============================================================================
--      Copyright (c) 2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
--==============================================================================
local i18n = require "i18n"

i18n.locales.en_US = {
  ["DEVICE UNAVAILABLE"] = "DEVICE UNAVAILABLE",
  ["Check the device is powered ON and connected to Alljoyn service."]
  = "Check the device is powered ON and connected to Alljoyn service."
}


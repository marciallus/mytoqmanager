--=============================================================================
--      Copyright (c) 2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
--==============================================================================
local i18n = require "i18n"

i18n.locales.es = {
  ["DEVICE UNAVAILABLE"] = "DISPOSITIVO NO DISPONIBLE",
  ["Check the device is powered ON and connected to Alljoyn service."]
  = "Compruebe si el dispositivo est� ACTIVADO y con�ctelo al servicio Alljoyn.",
  ["NO DEVICES FOUND"] = "NO SE HAN ENCONTRADO DISPOSITIVOS",
  ["Alljoyn supporting devices have not been found."] 
  = "No se han encontrado los dispositivos que admite Alljoyn."
}


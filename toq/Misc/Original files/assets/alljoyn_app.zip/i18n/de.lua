--=============================================================================
--      Copyright (c) 2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
--==============================================================================
local i18n = require "i18n"

i18n.locales.de = {
  ["DEVICE UNAVAILABLE"] = "GERÄT NICHT VERFÜGBAR",
  ["Check the device is powered ON and connected to Alljoyn service."]
  = "Stellen Sie sicher, dass das Gerät eingeschaltet („EIN“) und mit dem AllJoyn-Dienst verbunden ist.",
  ["NO DEVICES FOUND"] = "KEINE GERÄTE ERKANNT",
  ["Alljoyn supporting devices have not been found."] 
  = "Es wurden keine Geräte, die AllJoyn unterstützen, erkannt."
}


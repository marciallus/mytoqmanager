--=============================================================================
--      Copyright (c) 2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
--==============================================================================
local i18n = require "i18n"

i18n.locales.zu = {
  ["DEVICE UNAVAILABLE"] = "ECIVED ELBALIAVANU",
  ["Check the device is powered ON and connected to Alljoyn service."]
  = "Kcehc eht ecived si derewop NO dna detcennoc ot Alljoyn ecivres.",
  ["NO DEVICES FOUND"] = "ON SECIVED DNUOF",
  ["Alljoyn supporting devices have not been found."] 
  = "Alljoyn gnitroppus secived evah ton neeb dnuof."
}


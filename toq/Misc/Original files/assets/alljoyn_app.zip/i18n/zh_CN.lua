--=============================================================================
--      Copyright (c) 2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
--==============================================================================
local i18n = require "i18n"

i18n.locales.zh_CN= {
  ["DEVICE UNAVAILABLE"] = "无法使用设备",
  ["Check the device is powered ON and connected to Alljoyn service."]
  = "确认设备已开机且连接到Alljoyn服务",
  ["NO DEVICES FOUND"] = "找不到设备",
  ["Alljoyn supporting devices have not been found."] 
  = "没有支持Alljoyn的设备"
}


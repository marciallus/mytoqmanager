--==============================================================================
--      Copyright (c) 2013 - 2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
--==============================================================================


do
  local loadedChunk = assert(loadfile("fms:/app.zip?alljoynApp.lua"))
  setfenv(loadedChunk, getfenv())  -- inherit the current environment
  loadedChunk()
end


-- ============================================================
--    Copyright (c) 2014 Qualcomm Connected Experiences, Inc   
--                     All Rights Reserved                     
--             Qualcomm Connected Experiences, Inc             
-- ============================================================

clock {
  name = "Degrees",
  entrypoints = "ClockEntries"
}

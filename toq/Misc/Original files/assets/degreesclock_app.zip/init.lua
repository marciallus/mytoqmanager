-- =============================================================================
--      Copyright (c) 2013-2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
-- ==============================================================================

----------------------
-- Global variables --
----------------------

oo = require "oo"   -- get the Object Oriented library
ui = require "ui"   -- get the UI library
dt = require "datetime"
platform = require "platform"

--The Degrees Clock class overrides the built-in Clock class
DegreesClock = oo.class("DegreesClock", ui.Clock)

function DegreesClock:construct()
  print ("in construct")

  -- Base part of zip files
  self.appZip = "fms:/app.zip?"
  self.temperatureDat = "fms:/temperature.dat"

  local layout = ui.Layout(self)

  -- draw the icon
  local bgPath = self.appZip .. "degrees_inverse_ND.img"
  print (bgPath)

  self.backgroundIcon = layout:addIcon{path = bgPath}

  -- Analog Clock
  print("creating analog clock")
  self.handColor = "m_7"
  self.analogClock = ui.AnalogClock({ left=0, top=0, right=182, bottom=189 })
  self.analogClock:setProp { 
     handColor = self.handColor,
     handWidth = 4,
     hourRadius = 38,
     minuteRadius = 58,
     hourTailRadius = 10,
     minuteTailRadius = 10,
  }
  layout:addWidget(self.analogClock)

  -- reset and the time prompt
  local textLeftMargin = 180

  layout:resetGeometry()
  layout:indent(textLeftMargin)
  layout:addVerticalSpace(43)
  layout:direction(ui.LayoutDirection.VERTICAL)

  -- Temperature
  self.temperatureColor = "m_0"

  -- Use the hex UTF-8 encoding for the degrees symbol
  -- 0xC2(194) 0xB0(176) in decimal and then use the escape
  -- character in front of the decimal values
  self.degreesSymbol = "\194\176"

  self.noTemperature = "---"
  self.temperatureContent = self.noTemperature 
  self.temperature = layout:addText {
     content = self.temperatureContent, lines = 1, 
     color = self.temperatureColor,
     font = { size=53, weight="light" },
  }

  -- Month
  self.month = "ABC"
  self.monthDay = "00"
  self.charGap = 14

  self.timeColor = "m_22"
  self.timeFont = { size=25, weight = "bold" }

  local textRightMargin = 264

  layout:addVerticalSpace(2)
  layout:indent(0, textRightMargin)
  layout:direction(ui.LayoutDirection.HORIZONTAL)
  layout:hAlign(ui.LayoutHAlign.LEFT)
  layout:setConstrainedWidth(30)

  self.monthText1 = layout:addText {
     content = self.month:sub(1, 1),
     color = self.timeColor, 
     font = self.timeFont,
  }

  self.monthText2 = layout:addText {
     content = self.month:sub(2, 2),
     color = self.timeColor, 
     font = self.timeFont,
  }
  
  self.monthText3 = layout:addText {
     content = self.month:sub(3, 3),
     color = self.timeColor, 
     font = self.timeFont,
  }

  -- Month Day
  layout:resetGeometry()
  layout:direction(ui.LayoutDirection.HORIZONTAL)
  layout:hAlign(ui.LayoutHAlign.LEFT)
  layout:indent(textLeftMargin, textRightMargin)
  layout:addVerticalSpace(136)

  self.monthDayText1 = layout:addText {
     content = self.monthDay:sub(1, 1),
     color = self.timeColor, 
     font = self.timeFont,
  }

  self.monthDayText2 = layout:addText {
     content = self.monthDay:sub(2, 2),
     color = self.timeColor, 
     font = self.timeFont,
  }

  -- Change colors to the first state
  self:changeColors()

  print ("Constructed")

  return 0
end

function DegreesClock:moveText(x, text)
  local coords = text:getCoords()
  text:move(x, coords.top)
end

function DegreesClock:getTextLeft()
  -- As the text widths to maintain a central position for the
  -- Month text we calculate the width of the text, the width
  -- from the clock to the right edge, subtract them, divide by 2
  -- and offset from the parent left
 local clockCoords = self.analogClock:getCoords()

 -- (-20) is the edge of the clock dots
 local clockRight = clockCoords.right - 20
 local parentCoords = self:getCoords()

 local outerWidth = parentCoords.right - clockRight + 1
 
 local strWidth, _ = self.monthText1:getStringBBox(self.month, self.timeFont)
 local innerWidth = strWidth + (2 * self.charGap)
 return clockRight + math.floor((outerWidth - innerWidth)/2)
end

function DegreesClock:updateTimeValues(timeModel)
  local newMonth = timeModel:getTimeString("%#b")
  local newMonthDay = timeModel:getTimeString("%#d")

  if newMonth == self.month and 
     newMonthDay == self.monthDay then
     -- Optimization
     print ("Nothing to do the date hasn't changed")
     return
  end

  print ("Updating the date to " .. " " .. newMonth .. " " .. newMonthDay)
  self.month = newMonth
  self.monthDay = newMonthDay

  -- Set the text on the three month text boxes
  -- and move them into position

  -- First letter of the Month
  local textLeft = self:getTextLeft()
  self:moveText(textLeft, self.temperature)
  self:moveText(textLeft, self.monthText1)
  self:moveText(textLeft, self.monthDayText1)

  local newText = self.month:sub(1, 1)
  local strWidth, _ = self.monthText1:getStringBBox(newText, self.timeFont)
  self.monthText1:setProp{ content = newText }

  -- Second letter of the Month
  newText = self.month:sub(2, 2)
  self.monthText2:setProp{ content = newText }
  textLeft = textLeft + strWidth + self.charGap
  self:moveText(textLeft, self.monthText2)

  -- We need this for the month day
  local textLeft2 = textLeft

  -- Third letter of the Month
  strWidth, _ = self.monthText2:getStringBBox(newText, self.timeFont)
  textLeft = textLeft + strWidth + self.charGap

  self.monthText3:setProp{ content = self.month:sub(3, 3) }
  self:moveText(textLeft, self.monthText3)

  -- Set the text on the monthDay text boxes or hide it
  self.monthDayText1:setProp{ content = self.monthDay:sub(1, 1) }
  if #self.monthDay > 1 then
     -- coords is at the middle month char
     self.monthDayText2:setProp { 
        content = self.monthDay:sub(2, 2),
        visible = true}
     self:moveText(textLeft2, self.monthDayText2)
  else
     self.monthDayText2:setProp {visible = false}
  end

  runTempFile(temperatureDat)
end

function DegreesClock:changeColors()
  print("In changeColors: " .. self.timeColor)

  local bgPath = self.appZip .. "degrees_"
  if self.timeColor == "m_41" then
    self.timeColor = "m_22"
    self.handColor = "m_7"
    self.temperatureColor = "m_0"
    bgPath = bgPath .. "inverse_"
  else
    self.timeColor = "m_41"
    self.handColor = "m_56"
    self.temperatureColor = "m_63"
  end

  -- Update the time
  print("In changeColors: " .. self.timeColor)
  self.analogClock:setProp{ handColor = self.handColor }

  self.temperature:setProp{ color = self.temperatureColor }

  self.monthText1:setProp{ color = self.timeColor }
  self.monthText2:setProp{ color = self.timeColor }
  self.monthText3:setProp{ color = self.timeColor }

  self.monthDayText1:setProp{ color = self.timeColor }
  self.monthDayText2:setProp{ color = self.timeColor }

  bgPath = bgPath .. "ND.img"
  print ("Setting the background to: " .. bgPath)
  self.backgroundIcon:setProp{path = bgPath}
end

function DegreesClock:runTempFile(path)
  -- Runs the temperature.dat file
  if path == nil then
    path = ""
  end
  print("in runTempFile: " .. path)

  -- Clear everything out, before loading the new data
  self.temperatureContent = nil

  f, err = loadfile(self.temperatureDat)
  if not f then
    print("Error in running " .. self.temperatureDat .. ": " .. err .. "\n")
    return
  end

  newData = {}
  setfenv(f, newData )
  f()

  if newData.currentTemp ~= nil then
     self.temperatureContent = tostring(newData.currentTemp) .. self.degreesSymbol
  else
     self.temperatureContent = self.noTemperature
  end

  print ("Temperature updated to: " .. self.temperatureContent)
  self.temperature:setProp{content = self.temperatureContent}
  return 0
end

--
-- The clock we are going to return 
g_degreesClock = nil

TemperatureMonitor = oo.class("TemperatureMonitor", platform.FMSMonitor)

function TemperatureMonitor:onUpdate(path)
  return g_degreesClock:runTempFile(path)
end

function TemperatureMonitor:onDelete(path)
  return self:onUpdate(path)
end

function TemperatureMonitor:onParentDelete(path)
  return self:onUpdate(path)
end

--
-- startClock: The main entry point to the clock, returns a clock object
--
function newClock ()
  print ("Calling newClock")
  g_degreesClock = DegreesClock()

  if g_degreesClock == nil then
     return nil
  end

  local tempMonitor = TemperatureMonitor {path = g_degreesClock.temperatureDat }
  if tempMonitor == nil then
     print ("Failed to create the fms monitor for temperature.dat")

     -- Destroy the clock
     g_degreesClock:destroy()
     return nil
  end

  -- Load up any existing temperature.dat file
  g_degreesClock:runTempFile(g_degreesClock.temperatureDat)

  return g_degreesClock
end

-- This is the table of all entry points into the clock
ClockEntries = {
  createclock = newClock
}

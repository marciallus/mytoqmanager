-- =============================================================================
--      Copyright (c) 2013-2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
-- ==============================================================================

----------------------
-- Global variables --
----------------------

oo = require "oo"   -- get the Object Oriented library
ui = require "ui"   -- get the UI library
dt = require "datetime"
platform = require "platform"

--The Degrees Clock class overrides the built-in Clock class
DegreesClock = oo.class("DegreesClock", ui.Clock)

function DegreesClock:construct()
  print ("in construct")

  -- Base part of zip files
  self.appZip = "fms:/app.zip?"
 
  local layout = ui.Layout(self)

  -- draw the icon
  local bgPath = self.appZip .. "clement_clock_inverse_ND.img"
  print (bgPath)

  self.backgroundIcon = layout:addIcon{path = bgPath}

  -- Analog Clock
  print("creating analog clock")
  self.handColor = "m_56"
  self.analogClock = ui.AnalogClock({ left=112, top=12, right=274, bottom=178 })
  self.analogClock:setProp { 
     handColor = self.handColor,
     handWidth = 6,
     hourRadius = 48,
     minuteRadius = 68,
     hourTailRadius = 10,
     minuteTailRadius = 10,
  }
  layout:addWidget(self.analogClock)

  -- reset and the time prompt
  local textLeftMargin = 10



  
  self.month = "ABC"
  self.monthDay = "00"
  self.charGap = 14

  self.timeColor = "m_22"
  self.timeFont = { size=18, weight = "bold" }

  local textRightMargin = 264

-- Month Day
  layout:resetGeometry()
  layout:addVerticalSpace(10)
  layout:indent(0, textRightMargin)
  layout:direction(ui.LayoutDirection.HORIZONTAL)
  layout:hAlign(ui.LayoutHAlign.LEFT)
  layout:setConstrainedWidth(30)

  self.monthDayText1 = layout:addText {
     content = self.monthDay:sub(1, 1),
     color = self.timeColor, 
     font = self.timeFont,
  }

  self.monthDayText2 = layout:addText {
     content = self.monthDay:sub(2, 2),
     color = self.timeColor, 
     font = self.timeFont,
  }

 -- Month

  layout:resetGeometry()
  layout:addVerticalSpace(30)
  layout:indent(0, textRightMargin)
  layout:direction(ui.LayoutDirection.HORIZONTAL)
  layout:hAlign(ui.LayoutHAlign.LEFT)
  layout:setConstrainedWidth(30)

  self.monthText1 = layout:addText {
     content = self.month:sub(1, 1),
     color = self.timeColor, 
     font = self.timeFont,
  }

  self.monthText2 = layout:addText {
     content = self.month:sub(2, 2),
     color = self.timeColor, 
     font = self.timeFont,
  }
  
  self.monthText3 = layout:addText {
     content = self.month:sub(3, 3),
     color = self.timeColor, 
     font = self.timeFont,
  }

  

  -- Change colors to the first state
  self:changeColors()
  
  print ("Constructed")

  return 0
end

function DegreesClock:moveText(x, text)
  local coords = text:getCoords()
  text:move(x, coords.top)
end

function DegreesClock:getTextLeft()
  
 
 -- As the text widths to maintain a central position for the
 -- Month text we calculate the width of the text, the width
 -- from the clock to the right edge, subtract them, divide by 2
 -- and offset from the parent left
 local clockCoords = self.analogClock:getCoords()

 -- (-20) is the edge of the clock dots
 local clockRight = clockCoords.right - 20
 local parentCoords = self:getCoords()

 -- local outerWidth = parentCoords.right - clockRight + 1
 local outerWidth = clockCoords.left
 
 local strWidth, _ = self.monthText1:getStringBBox(self.month, self.timeFont)
 local innerWidth = strWidth + (2 * self.charGap)

 --return clockRight + math.floor((outerWidth - innerWidth)/2)
 return math.floor((outerWidth - innerWidth)/2)	

end

function DegreesClock:updateTimeValues(timeModel)
  -- local newDay = timeModel:getTimeString("%#a")
  local newMonth = timeModel:getTimeString("%#b")
  local newMonthDay = timeModel:getTimeString("%#d")

  if newMonth == self.month and 
     newMonthDay == self.monthDay then
    -- and newhDay == self.day
     -- Optimization
     print ("Nothing to do the date hasn't changed")
     return
  end

  print ("Updating the date to " .. " " .. newMonth .. " " .. newMonthDay)
  -- self.day = newDay	
  self.month = newMonth
  self.monthDay = newMonthDay

  -- Set the text on the three month text boxes
  -- and move them into position

  -- First letter of the Month
  local textLeft = self:getTextLeft()
  -- self:moveText(textLeft, self.dayText1)
  self:moveText(textLeft, self.monthText1)
  self:moveText(textLeft, self.monthDayText1)

  local newText = self.month:sub(1, 1)
  local strWidth, _ = self.monthText1:getStringBBox(newText, self.timeFont)
  self.monthText1:setProp{ content = newText }

  -- Second letter of the Month
  newText = self.month:sub(2, 2)
  self.monthText2:setProp{ content = newText }
  textLeft = textLeft + strWidth + self.charGap
  self:moveText(textLeft, self.monthText2)

  -- We need this for the month day
  local textLeft2 = textLeft

  -- Third letter of the Month
  strWidth, _ = self.monthText2:getStringBBox(newText, self.timeFont)
  textLeft = textLeft + strWidth + self.charGap

  self.monthText3:setProp{ content = self.month:sub(3, 3) }
  self:moveText(textLeft, self.monthText3)

  -- Set the text on the monthDay text boxes or hide it
  self.monthDayText1:setProp{ content = self.monthDay:sub(1, 1) }
  if #self.monthDay > 1 then
     -- coords is at the middle month char
     self.monthDayText2:setProp { 
        content = self.monthDay:sub(2, 2),
        visible = true}
     self:moveText(textLeft2, self.monthDayText2)
  else
     self.monthDayText2:setProp {visible = false}
  end
end

function DegreesClock:changeColors()
  print("In changeColors: " .. self.timeColor)

  local bgPath = self.appZip .. "clement_clock_"
  if self.timeColor == "m_41" then
    self.timeColor = "m_22"
    self.handColor = "m_56"
    bgPath = bgPath .. "inverse_"
  else
    self.timeColor = "m_41"
    self.handColor = "m_7"
  end

  -- Update the time
  print("In changeColors: " .. self.timeColor)
  self.analogClock:setProp{ handColor = self.handColor }


  self.monthText1:setProp{ color = self.timeColor }
  self.monthText2:setProp{ color = self.timeColor }
  self.monthText3:setProp{ color = self.timeColor }

  self.monthDayText1:setProp{ color = self.timeColor }
  self.monthDayText2:setProp{ color = self.timeColor }

  bgPath = bgPath .. "ND.img"
  print ("Setting the background to: " .. bgPath)
  self.backgroundIcon:setProp{path = bgPath}
end



--
-- The clock we are going to return 
g_degreesClock = nil



--
-- startClock: The main entry point to the clock, returns a clock object
--
function newClock ()
  print ("Calling newClock")
  g_degreesClock = DegreesClock()

  if g_degreesClock == nil then
     return nil
  end


 
  return g_degreesClock
end

-- This is the table of all entry points into the clock
ClockEntries = {
  createclock = newClock
}

--=============================================================================
--      Copyright (c) 2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
--==============================================================================
local i18n = require "i18n"

i18n.locales.zu = {
  ["NO ANDROID NOTIFICATIONS"] = "SNOITACIFITON DIORDNA ON",
  ["Notifications will appear if you have enabled them in the Toq app."]
  = ".ppa qoT eht ni meht delbane evah uoy fi raeppa lliw snoitacifitoN"
}


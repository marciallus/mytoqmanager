--=============================================================================
--      Copyright (c) 2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
--==============================================================================
local i18n = require "i18n"

i18n.locales.es = {
  ["NO ANDROID NOTIFICATIONS"] = "NO HAY NOTIFICACIONES DE ANDROID",
  ["Notifications will appear if you have enabled them in the Toq app."]
  = "Las notificaciones aparecerán si las tiene activadas en la aplicación Toq."
}


--=============================================================================
--      Copyright (c) 2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
--==============================================================================
local i18n = require "i18n"

i18n.locales.zh_CN = {
  ["NO ANDROID NOTIFICATIONS"] = "没有安卓通知",
  ["Notifications will appear if you have enabled them in the Toq app."]
  = "如果在Toq app内启用通知功能，可显示通知"
}


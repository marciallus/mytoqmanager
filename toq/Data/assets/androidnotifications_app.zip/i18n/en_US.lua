--=============================================================================
--      Copyright (c) 2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
--==============================================================================
local i18n = require "i18n"

i18n.locales.en_US = {
  ["NO ANDROID NOTIFICATIONS"] = "NO ANDROID NOTIFICATIONS",
  ["Notifications will appear if you have enabled them in the Toq app."]
  = "Notifications will appear if you have enabled them in the Toq app."
}


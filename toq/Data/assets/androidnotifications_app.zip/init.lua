-- =============================================================================
--      Copyright (c) 2013-2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
-- ==============================================================================



----------------------
-- Global variables --
----------------------


oo = require "oo"   -- get the Object Oriented library
ui = require "ui"   -- get the UI library
platform = require "platform" -- get the fms library
io = require "io"   -- get the IO library
string = require "string"
local i18n = require "i18n" 

-- This is where all the notifications (cards.dat ones) currently available are stored
notifycards = {}

-- This is where all the popup cards are stored, indexed by card.id.
popupcards = {}

-- This is where all the data cards are stored, indexed by card.id.
datacards = {}

-- This is the list of cards, if there is at least 1 card in notifycards table,
-- otherwise it is nil
cardlist = nil

-- This is a text prompt that says "No cards available"
nocardsprompt = nil

-- This is a help message prompt that says "Check to see if notifications are
-- enabled"
helpmessage = nil

-- cards currently open. Each entry in this table has a key of the card ID,
-- and each value is an array of three entries - the panel for the card,
-- the scrollable for the panel, and the index into openedcardsarray
-- (defined below)
openedcards = {}

-- Same openedcards list, this time stored as an array with [1] being the
-- oldest card
openedcardsarray = {}

-- Maximum number of popup cards we allow at a single time, older cards are
-- purged and their panels dismissed if more than MAX_POPUP_CARDS are opened
-- at a single time
MAX_POPUP_CARDS = 20

CARDS_FILE_PATH = "fms:/cards.dat"
DATA_CARDS_FILE_PATH = "file:/datacards.dat"

-- divider line image, is cached so that it does not need to be loaded again
-- and again
dividerline = nil
--------------
-- Classes  --
--------------

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-- AndroidNotificationsApp : This is the table of all entry points into the app
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
AndroidNotificationsApp = {
}

-- The CardList class overrides the built-in List widget to provide
-- the list of notifications.

CardList = oo.class("CardList", ui.List)


function CardList:onItemSelected(pos)
  print("Card Selected : " .. pos)
  showdetailscard(notifycards[pos + 1])
end

function CardList:onNewItem(posrect, index)
  print("In onnewitem : " .. index)
  w, _ = createnewcard(posrect, index)
  return w
end

function CardList:onItemHeight(index)
  if index >= #notifycards then
    return nil
  end

  -- 6 pixels border for the card style sheet.
  local l_rect = { left = 6, top = 6, bottom = 191-6, right = 287-6, }
  local card
  local height  -- height of the card
  card, height = createnewcard(l_rect, index)
  -- we need to destroy this card and all its children since its not being
  -- attached to a widget that is managed by the app manager
  card:destroy()
  return height
end


-- The DetailsPanel class is used to show the details of a specific card. We override
-- various methods of the panel class.

DetailsPanel = oo.class("DetailsPanel", ui.Panel)

function DetailsPanel:init(card)
  self.superClass().init(self, {})
  self.card = card
end

function DetailsPanel:onClose()
  -- remove the reference from openedcards
  local idx = openedcards[self.card.id][3]
  table.remove(openedcardsarray, idx)
  openedcards[self.card.id] = nil
  if self.card.cardevents and self.card.cardevents == "true" then
    sendnotification(self.card.id, "closed")
  end
  self.superClass().onClose(self)
end

function DetailsPanel:onFocus()
  print("In panel onFocus")
  if self.card.cardevents and self.card.cardevents == "true" then
    sendnotification(self.card.id, "visible")
  end
  self.superClass().onFocus(self)
end

function DetailsPanel:onDefocus()
  print("In panel onDefocus")
  if self.card.cardevents and self.card.cardevents == "true" then
    sendnotification(self.card.id, "invisible")
  end
  self.superClass().onDefocus(self)
end



---------------
-- Functions --
---------------

--
-- sendnotification: Generates an app directed message to peer on Android
-- Generates a "CardEvent" message with ID and content such as "open",
-- "visible", "invisible" and "closed"
--
function sendnotification(cardid, content)
  contentmsg = "CardEvent { \n"
  contentmsg = contentmsg .. "id = \"" .. cardid .. "\",\n"
  contentmsg = contentmsg .. "event = \"" .. content .. "\"\n}\n"
  sendmessage(contentmsg)
end

--
-- populatedetailscard: Populates the actual scrollable panel with the
-- contents of the passed in card
--
--
function populatedetailscard(detailsscrollable, card)
  local panellayout = ui.Layout(detailsscrollable)
  panellayout:direction(ui.LayoutDirection.VERTICAL)
  panellayout:hAlign(ui.LayoutHAlign.LEFT)

  local iconpath = card.icon or "fms:/app.zip?small.img"

  panellayout:addVerticalSpace(14)
  panellayout:indent(23, 7)

  local imgicon = panellayout:addIcon {
    path = iconpath,
    altpath = "fms:/app.zip?small.img"
  }
  imgicon = imgicon:getCoords()

  -- vertical offset equal to the y-length of the icon
  panellayout:addVerticalSpace(-1 * (imgicon.bottom - imgicon.top))
  local dateTimeIndent = 7 + (imgicon.right - imgicon.left)
  panellayout:indent(dateTimeIndent, 0)

  panellayout:addText {
    content = card.app, lines = 1, color = "m_0",
    font = { size = 29 }
  }
  panellayout:addDateTime {
     -- the notifycard/popupcard comes with time in millis, convert to seconds
     -- We are ok with truncating the value rather than rounding it
    value = string.match(card.time, "T") and card.time or card.time / 1000,
    format="%#b %d, %I:%M %p", relativeFormat="%#q %I:%M %p",
    color = "m_3",
    font = { size = 20, weight = "bold" }
  }

  panellayout:indent(-1 * dateTimeIndent, 0)
  panellayout:addVerticalSpace(13)
  panellayout:addText {
    content = card.title, lines = 1, color = "m_0",
    font = { size = 24, weight = "bold" }
  }
  panellayout:addVerticalSpace(3)

  if card.subtitle then
    panellayout:addText { content = card.subtitle,
                          color = "m_0",
                          font = { size = 26 }}
  end

  if card.detail then
    for i, v in ipairs(card.detail) do
      if i > 1 and card.divider and card.divider == "true" then
        if not dividerline then
          dividerline = ui.Image.new { path = "fms:/app.zip?divider.img" }
        end
        panellayout:addIcon {image = dividerline }
        panellayout:addVerticalSpace(6)
      end
      panellayout:addText {content = v, color = "m_0", font = { size = 26 }}
    end
  end

  panellayout:addVerticalSpace(15)

end


--
-- Common function to show the details card. Can be called if:
-- App is launched in order to show a popup (i.e. ongoing notification)
-- App is already launched and user selects a card 
-- Also generates app directed "opened" message for this card ID.
-- isPopupNotification if true, panel slide-transition is suppressed and marked
-- as minimizable panel.
--
function showdetailscard(card, isPopupNotification)
  print("Create details card with id [" .. card.id .. "]")

  local p = DetailsPanel(card)

  -- for popup notifications make them minimizeable
  if isPopupNotification then p:setProp{ minimizeable = true } end

  local s = ui.Scrollable {
    left = 0, top = 0, right = 287, bottom = 191
  }

  p:add(s, true)  -- true == relative to container
  populatedetailscard(s, card)

  -- add the information to openedcards
  openedcardsarray[#openedcardsarray + 1] = card
  openedcards[card.id] = {p, s, #openedcardsarray}

  -- Notify Android peer that card is open
  if card.cardevents and card.cardevents == "true" then
    sendnotification(card.id, "open");
  end

  -- Push panel onto screen
  p:show(isPopupNotification or false)  -- popups don't do sliding transition
end


--
-- updatedetailscard: Called for every PopupCard
-- app directed message. We check in here if
-- 1. There is a popup or details card on the screen
-- 2. The card ID matches the card ID for which we
--    have received the update.
-- 3. In that case, we update the details panel with
--    the latest information.
--
--
function updatedetailscard(card)

  if not openedcards[card.id] then 
    return false
  end

  print("Updating existing popup for " .. card.id)
  -- openedcards stores an array as its value with two members:
  -- the panel and the scrollable
  local p, s, idx = unpack(openedcards[card.id])

  -- Remove and destroy this scrollable from the panel, we are creating a new one
  s:destroy()
  s = ui.Scrollable {
    left = 0, top = 0, right = 287, bottom = 191
  }
  p:add(s, true)  -- relative to container

  -- add the information to openedcards
  openedcards[card.id] = {p, s, idx}
  populatedetailscard(s, card)
  p:show(true) -- suppress transition

  return true
end


--
-- createnewcard: create a new card for the given rectangle and using the card index to the
-- model. This card is shown in the first screen - the list of all notifications.
--
--
function createnewcard(posrect, index)
  if index >= #notifycards then
    return nil
  end
  
  local mycard = ui.Card { left = posrect.left, right = posrect.right,
                           top = posrect.top, bottom = posrect.bottom,
                           pos = index, idx = index + 1 }
  local cardlayout = ui.Layout(mycard)
  cardlayout:direction(ui.LayoutDirection.VERTICAL)
  cardlayout:hAlign(ui.LayoutHAlign.LEFT)
  local indentInsideCard = 23 - 6
  cardlayout:addVerticalSpace(indentInsideCard)

  cardlayout:indent(indentInsideCard, 0)
  
  local iconpath = "fms:/app.zip?small.img"
  if notifycards[index+1].icon then
    iconpath = notifycards[index+1].icon
  end

  local imgicon = cardlayout:addIcon {
    path = iconpath,
    altpath = "fms:/app.zip?small.img"
  }
  imgicon = imgicon:getCoords()

  -- vertical offset equal to the y-length of the icon
  cardlayout:addVerticalSpace(-1 * (imgicon.bottom - imgicon.top))
  cardlayout:indent((78 - 23), 0)

  cardlayout:addText {
    content = notifycards[index + 1].app, lines = 1, color = "m_48",
    font = { size = 29 }
  }
  cardlayout:addDateTime {
    -- the notifycard comes with time in millis, convert to seconds
    -- We are ok with truncating the value rather than rounding it
    value = notifycards[index + 1].time / 1000,
    format="%#b %d, %I:%M %p", relativeFormat="%#q %I:%M %p",
    color = "m_3",
    font = { size = 20, weight = "bold" }
  }
  
  cardlayout:indent((23 - 78), 0)
  cardlayout:addVerticalSpace(10)
  
  cardlayout:addText {
    content = notifycards[index+1].title, lines = 1, color = "m_0",
    font = { size = 24, weight = "bold" }
  }

  cardlayout:indent(0, indentInsideCard)
  if notifycards[index+1].detail then
    cardlayout:addText {
      content = table.concat(notifycards[index+1].detail, "\n"), lines = 2, color = "m_0",
      font = { size = 26 }
    }
  end

  cardlayout:addVerticalSpace(6)   -- add additional space ending the card
  
  return mycard, cardlayout:height()
end


function startswith(outer, inner)
   return string.sub(outer,1,string.len(inner))==inner
end

--
-- runCardsFile: Utility function that runs the cards.dat file from fms in an
-- empty environment that only has one function - "NotifyCard" defined in it.
-- and populates the "notifycards" table with the cards information in the
-- cards.dat file
--
--
function readCards(path, functionTable)
  -- compiled function and compile status
  local f, err
  functionTable = functionTable or
                  { NotifyCard = function(card)
                                    notifycards[#notifycards + 1] = card
                                 end
                  }

  if startswith(path, "file:/") then
    local fp = io.open(path, "r")
    if not fp then
      print("Error in opening " .. path .. "\n")
      return
    else
      local contents = fp:read("*all")
      -- in the event that an update has caused all the data to be deleted
      -- from the file, the contents read out would be nil, and
      -- loadstring(nil) throws a Lua exception
      if not contents then
        return
      end
      f, err = loadstring(contents)
    end
  else
    f, err = loadfile(path)
  end

  if not f then
    print("Error in running " .. path .. ": " .. err .. "\n")
  else
    -- 
    -- NotifyCard: Helper function that is called with a card from each notification
    -- entry in cards.dat
    setfenv(f, functionTable)
    f()
  end
end

--
-- removeEmptyPrompt: Is called to remove any existing "No Android notifications"
-- prompt and the help message that goes with it.
--
--
function removeEmptyPrompt(targetpanel)
  if nocardsprompt then
    nocardsprompt:destroy()
    nocardsprompt = nil
  end
  if helpmessage then
    helpmessage:destroy()
    helpmessage = nil
  end
end

--
-- addEmptyPrompt: Is called to add an empty "No Android notifications" prompt
--
--
function addEmptyPrompt(targetpanel)
  targetpanel:setProp{ background = "m_63" }  -- change background to white
  removeEmptyPrompt(targetpanel)
  local panellayout = ui.Layout(targetpanel)
  panellayout:addVerticalSpace(19)
  panellayout:indent(19, 80)
  nocardsprompt = panellayout:addText {
    content = i18n"NO ANDROID NOTIFICATIONS", 
    lines = 2, color = "m_3",
    font = { size = 20, weight = "bold"}
  }

  panellayout:resetGeometry()
  panellayout:addVerticalSpace(70)
  panellayout:indent(19, 19)
  helpmessage = panellayout:addText {
    content = i18n"Notifications will appear if you have enabled them in the Toq app.", 
    lines = 0, color = "m_0",
    font = { size = 26 }
  }

end

--
-- populate: Populates the provided panel with the list of cards in cardlist
-- This creates the main startup screen of the app
--
--
function populate(targetpanel)
  if #notifycards == 0 then
    -- If there was an existing list of cards, need to remove it from
    -- the panel and destroy it
    if cardlist then
      cardlist:destroy()
      cardlist = nil
    end

    addEmptyPrompt(targetpanel)
  else
    if cardlist then
      -- In the case where there are cards available, and a previous cardlist exists
      -- we can simply reset the cardlist to repopulate it
      print("CardList resizing. For " .. #notifycards .. " cards.")
      cardlist:reset(#notifycards)
    else
      -- Remove the nocardsprompt from the panel if its there
      removeEmptyPrompt(targetpanel)

      targetpanel:setProp{ background = "m_27" }  -- change background to 27

      -- If no previous cardlist, then create one and add to panel
      cardlist = assert(CardList { left = 0, top = 0, bottom = 191, right = 287,
                                   numitems = #notifycards, itemheight = 160 },
                        "Card list creation failed")
      targetpanel:add(cardlist, true)  -- relative to container
    end
  end
  -- force a gc cycle to reclaim the old cards and prompts, otherwise too much
  -- fragmentation is being created. 
  -- Better management of garbage collection will move into the framework in the
  -- future
  collectgarbage("collect")
end


--
-- updatecards: Is called in response to fms file cards.dat being updated
--
--
function updatecards()
  print("Update cards")
  notifycards = {}
  readCards(CARDS_FILE_PATH)
  readCards(DATA_CARDS_FILE_PATH)
  populate(mainpanel)
end

CardsMonitor = oo.class("CardsMonitor", platform.FMSMonitor)


function CardsMonitor:onUpdate(path)
  print("Cards.dat update : " .. path)
  updatecards()
  return 0
end

function CardsMonitor:onDelete(path)
  print("Cards.dat deleted : " .. path)
  updatecards()
  return 0
end

function CardsMonitor:onParentDelete(path)
  print("Cards.dat directory deleted: " .. path);
  updatecards();
  return 0
end

MainPanel = oo.class("MainPanel", ui.Panel)

function MainPanel:init(args)
  self.superClass().init(self, args)
end

function MainPanel:onClose()
  mainpanel = nil
  cardlist = nil
  nocardsprompt = nil
  helpmessage = nil
end
--
-- onStart: The main entry point to the app. Can optionally return a panel
--
--
function AndroidNotificationsApp:onStart()
  i18n.setLocale(platform.getCurrentLocale())
  if not mainpanel then   -- create once
    mainpanel = assert(MainPanel( { color = "m_27" } ),
                       "Main panel creation failed")
  end

  updatecards()

  if not fms_listener then   -- register once
    fms_listener = assert(CardsMonitor ( { path = CARDS_FILE_PATH} ),
                          "FMS monitor failed")
  end

  return mainpanel
end

--
-- onStop: Called when the app is about to be stopped
--
--
function AndroidNotificationsApp:onStop()
  if fms_listener then
    fms_listener:destroy()
    fms_listener = nil
  end
end

-- This serialize function is adapted from the lua documentation section on
-- Serialization, Saving Tables without Cycles
function serialize (f, o, indent)
  indent = indent or 1
  indentstring = "  "
  if type(o) == "number" then
    f:write(o)
  elseif type(o) == "string" then
    f:write(string.format("%q", o))
  elseif type(o) == "table" then
    f:write("{\n")
    for k,v in pairs(o) do
      f:write(string.rep(indentstring, indent))
      f:write("[")
      serialize(f, k, indent)
      f:write("] = ")
      serialize(f, v, indent + 1)
      f:write(",\n")
    end
    f:write("}\n")
  else
    error("cannot serialize a " .. type(o))
  end
end

--
-- removeoldestcard: Removes the oldest popupcard in the openedcards list. Also
-- dismisses the card's panel
--
--
function removeoldestcard()
  local cardtoremove = openedcardsarray[1]
  print("Removing oldest card with id " .. cardtoremove.id);
  popupcards[cardtoremove.id] = nil
  local p = openedcards[cardtoremove.id][1]
  p:dismiss()
end

-- 
-- PopupCard: This can be one of the instructions inside
-- a received app directed message.
function PopupCard(card)
  print("PopupCard for card id " .. card.id)
  popupcards[card.id] = card

  -- First attempt to update an existing card, if it does not match, then
  -- show a new card.
  if not updatedetailscard(card) then
    -- We need to create a new popup. Since we only allow MAX_POPUP_CARDS at
    -- a time, check to see if we need to expire an old card
    if #openedcardsarray == MAX_POPUP_CARDS then
      print("Max cards exceeded, removing oldest card")
      removeoldestcard()
    end
    print("Creating new popup card for " .. card.id)
    showdetailscard(card, true) -- alert.
    devicemgr.set_vibe(devicemgr_vibe.short)  -- vibe on a new card display
  else
    -- donot vibe for updates to ongoing card
    if not isOngoingCard(card) then
      devicemgr.set_vibe(devicemgr_vibe.short)
    end
  end

  -- activate touch
  devicemgr.activate_touch(devicemgr_touch_activity.notification)
end

-- 
-- DeleteCard: Can be an insturction inside a received
-- app directed message.
function DeleteCard(card)
  print("DeleteCard for card id " .. card.id)
  if popupcards[card.id] then
    print("DeleteCard: Found card")
    popupcards[card.id] = nil

    if openedcards[card.id] then
      local p = openedcards[card.id][1]
      p:dismiss()
    end
  else
    print("DeleteCard: Not found")
  end
end

-- 
-- DataCard: This can be one of the instructions inside
-- a received app directed message.
function DataCard(card)
  print("DataCard for card id " .. card.id)
  -- begin by massaging the DataCard into the PopupCard/NotifyCard format
  card.app = card.app or " "
  -- Look for a . followed by some characters, at the end of the string
  dotlocation = string.find(card.app, "%.[%a]+$")
  if dotlocation and dotlocation > 0 then
    card.app = string.sub(card.app, dotlocation + 1)
  end


  if not datacards then
    readCards(DATA_CARDS_FILE_PATH,
              { DataCard = function(card)
                              datacards[card.id] = card
                           end
              })
  end

  if "delete" == card.cardtype then
    -- first simulate a delete for a popup
    DeleteCard(card)
    if datacards[card.id] then
      datacards[card.id] = nil
    end
  else
    -- first simulate a new/update event for a popup
    print("Card time " .. card.time)
    PopupCard(card)
    datacards[card.id] = card
  end

  -- now simulate an update to cards.dat by writing the datacards array out
  -- NOTE: There is an assumption here that in general these notifications
  -- come only one at a time. If there are multiple such notifications coming
  -- in in a single call to handlemessage, then it is better to write out the
  -- list inside handlemessage
  local f = assert(io.open(DATA_CARDS_FILE_PATH, "w"))
  for k,v in pairs(datacards) do
    f:write("NotifyCard ")
    serialize(f, v)
    f:write("\n")
  end
  f:close()

  if mainpanel then
    updatecards()
  end
end


--
-- TODO: A bit of hack to determine whether this card is an Ongoing kind. 
-- We piggyback on the interest for cardevents. A proper solution is to have 
-- an explicit field in the card table. Donot merge this to deck of cards
-- implementation.
--
function isOngoingCard(card)
  if card.cardevents and card.cardevents == "true" then
    return true
  end
  return false
end

--
-- onMessage(): The designated app directed message handler for this app
--
-- onMessage() is given a chunk of Lua code that it needs to execute
-- What happens when that chunk of Lua code runs is defined by the 
-- app itself. In the case of notification manager, we are expecting
-- PopupCard {} and DeleteCard {} calls in the app directed message
-- Thus we run the chunk in an env where only those two functions are
-- defined
--
--
function AndroidNotificationsApp:onMessage(messagefunc)
  print("Received App directed message")
  setfenv(messagefunc, { PopupCard = PopupCard,
                         DeleteCard = DeleteCard, 
                         DataCard = DataCard
                       })
  messagefunc()

  -- Force a gc cycle to reclaim the old cards and prompts, otherwise too 
  -- much fragmentation is being created. 
  -- This needs to move into the framework
  collectgarbage("collect")
  return false
end


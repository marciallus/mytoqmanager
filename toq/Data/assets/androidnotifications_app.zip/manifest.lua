-- ============================================================
--    Copyright (c) 2014 Qualcomm Connected Experiences, Inc   
--                     All Rights Reserved                     
--             Qualcomm Connected Experiences, Inc             
-- ============================================================

app {
  name = "Notifications",
  username = _("Notifications"),
  icon_white = "fms:/app.zip?white_ND.img",
  icon_color = "fms:/app.zip?color_ND.img",
  entrypoints = "AndroidNotificationsApp",
}

-- =============================================================================
--      Copyright (c) 2013-2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
-- ==============================================================================

----------------------
-- Global variables --
----------------------

oo = require "oo"   -- get the Object Oriented library
ui = require "ui"   -- get the UI library
dt = require "datetime"
platform = require "platform"

--~ string = require "string"
--~ io = require "io"   -- get the IO library


--~ -- This is where all the notifications (cards.dat ones) currently available are stored
--~ notifycards = {}


--~ -- Maximum number of popup cards we allow at a single time, older cards are
--~ -- purged and their panels dismissed if more than MAX_POPUP_CARDS are opened
--~ -- at a single time
--~ MAX_POPUP_CARDS = 6

--~ CARDS_FILE_PATH = "fms:/../com.qualcomm.qce.androidnotifications/cards.dat"


--The Degrees Clock class overrides the built-in Clock class
MyNewClock = oo.class("MyNewClock", ui.Clock)

function MyNewClock:construct()
	print ("in construct")

	-- Base part of zip files
	self.appZip = "fms:/app.zip?"

	local layout = ui.Layout(self)

	-- draw the icon
	local bgPath = self.appZip .. "newclock_inverse_ND.img"
	print (bgPath)

	self.backgroundIcon = layout:addIcon{path = bgPath}

	-- notifications

	--	updatecards()


	--~    layout:resetGeometry()
	--~    layout:indent(0, 0)
	--~    layout:direction(ui.LayoutDirection.HORIZONTAL)

	--~ 	for card in 1,MAX_POPUP_CARDS do

	--~ 		local iconpath = "fms:/app.zip?small.img"
	--~ 		if (i < (#notifycards+1)) then
	--~ 			iconpath = notifycards[i].icon or "fms:/app.zip?small.img"
	--~ 		end

	--~ 		self.icon[i] = layout:addIcon {
	--~ 			path = iconpath,
	--~ 			altpath = "fms:/app.zip?small.img"
	--~ 		}

	--~ 	end



	layout:resetGeometry()
	layout:indent(2)
	layout:addVerticalSpace(30)
	layout:direction(ui.LayoutDirection.VERTICAL)

	self.timeColor = "m_0"
	self.dateColor = "m_0"
	self.time = "01:23"
	self.timeFont = { size=100, weight = "light" }
	self.nday = "07"
	self.ndayFont = { size=64, weight="light" }
	self.day="Dimanche"
	self.dayFont = { size=24, weight="bold" }
	self.month="DECEMBRE"
	self.monthFont = { size=24, weight="bold" }

	self.timeText = layout:addText {
		content = self.time,
		color = self.timeColor,
		font = self.timeFont,
	}

	layout:addVerticalSpace(5)

	self.ndayText = layout:addText {
		content = self.nday,
		color = self.dateColor,
		font = self.ndayFont,
	}



	layout:resetGeometry()
	layout:indent(70)
	layout:addVerticalSpace(30+80)
	layout:direction(ui.LayoutDirection.VERTICAL)


	self.dayText = layout:addText {
		content = self.day,
		color = self.dateColor,
		font = self.dayFont,
	}

	layout:addVerticalSpace(1)

	self.monthText = layout:addText {
		content = self.month,
		color = self.dateColor,
		font = self.monthFont,
	}



  -- Change colors to the first state
  self:changeColors()

  print ("Constructed")

  return 0
end

function MyNewClock:updateTimeValues(timeModel)

--~ 	updatecards()
--~ 	for card in 1,MAX_POPUP_CARDS do

--~ 		local iconpath = "fms:/app.zip?small.img"
--~ 		if (i < (#notifycards+1)) then
--~ 			iconpath = notifycards[i].icon or "fms:/app.zip?small.img"
--~ 			self.icon[i]:setProp{path = iconpath,visible = true }
--~ 		else
--~ 			self.icon[i]:setProp{path = iconpath,visible = false }
--~ 		end

--~ 		self.icon[i] = layout:addIcon {
--~ 			path = iconpath,
--~ 			altpath = "fms:/app.zip?small.img"
--~ 		}

--~ 	end


  local newDay = timeModel:getTimeString("%#a")
  local newMonth = timeModel:getTimeString("%#b")
  local newMonthDay = timeModel:getTimeString("%#d")
  local newHour = timeModel:getTimeString("%I")
  local newMinutes = timeModel:getTimeString("%M")
  local ampm = timeModel:getTimeString("%p")

  if (ampm == "PM") then
	if (newHour == "0") then
		newHour = "00"
	end
	if (newHour == "1") then
		newHour = "13"
	end
	if (newHour == "2") then
		newHour = "14"
	end
	if (newHour == "3") then
		newHour = "15"
	end
	if (newHour == "4") then
		newHour = "16"
	end
	if (newHour == "5") then
		newHour = "17"
	end
	if (newHour == "6") then
		newHour = "18"
	end
	if (newHour == "7") then
		newHour = "19"
	end
	if (newHour == "8") then
		newHour = "20"
	end
	if (newHour == "9") then
		newHour = "21"
	end
	if (newHour == "10") then
		newHour = "22"
	end
	if (newHour == "11") then
		newHour = "23"
	end


  end

  if (ampm == "AM") then
	if (newHour == "0") then
		newHour = "00"
	end
	if (newHour == "1") then
		newHour = "01"
	end
	if (newHour == "2") then
		newHour = "02"
	end
	if (newHour == "3") then
		newHour = "03"
	end
	if (newHour == "4") then
		newHour = "04"
	end
	if (newHour == "5") then
		newHour = "05"
	end
	if (newHour == "6") then
		newHour = "06"
	end
	if (newHour == "7") then
		newHour = "07"
	end
	if (newHour == "8") then
		newHour = "08"
	end
	if (newHour == "9") then
		newHour = "09"
	end

  end

  if newMonth == "JAN" then
	newMonth = "Janvier"
  end
  if newMonth == "FEB" then
	newMonth = "Fevrier"
  end
  if newMonth == "MAR" then
	newMonth = "Mars"
  end
  if newMonth == "APR" then
	newMonth = "Avril"
  end
  if newMonth == "MAY" then
	newMonth = "Mai"
  end
  if newMonth == "JUN" then
	newMonth = "Juin"
  end
  if newMonth == "JUL" then
	newMonth = "Juillet"
  end
  if newMonth == "AUG" then
	newMonth = "Aout"
  end
  if newMonth == "SEP" then
	newMonth = "Septembre"
  end
  if newMonth == "OCT" then
	newMonth = "Octobre"
  end
  if newMonth == "NOV" then
	newMonth = "Novembre"
  end
  if newMonth == "DEC" then
	newMonth = "Decembre"
  end



  if newDay == "MON" then
	newDay = "Lundi"
  end
  if newDay == "TUE" then
	newDay = "Mardi"
  end
  if newDay == "WED" then
	newDay = "Mercredi"
  end
  if newDay == "THU" then
	newDay = "Jeudi"
  end
  if newDay == "FRI" then
	newDay = "Vendredi"
  end
  if newDay == "SAT" then
	newDay = "Samedi"
  end
  if newDay == "SUN" then
	newDay = "Dimanche"
  end


  if (newMonthDay == "1") then
		newMonthDay = "01"
	end
	if (newMonthDay == "2") then
		newMonthDay = "02"
	end
	if (newMonthDay == "3") then
		newMonthDay = "03"
	end
	if (newMonthDay == "4") then
		newMonthDay = "04"
	end
	if (newMonthDay == "5") then
		newMonthDay = "05"
	end
	if (newMonthDay == "6") then
		newMonthDay = "06"
	end
	if (newMonthDay == "7") then
		newMonthDay = "07"
	end
	if (newMonthDay == "8") then
		newMonthDay = "08"
	end
	if (newMonthDay == "9") then
		newMonthDay = "09"
	end


	self.timeText:setProp { content = newHour .. ":" .. newMinutes, visible = true }
	self.ndayText:setProp { content = newMonthDay, visible = true }
	self.dayText:setProp { content = newDay, visible = true }
	self.monthText:setProp { content = newMonth, visible = true }

end

function MyNewClock:changeColors()

	local bgPath = self.appZip .. "newclock_"




	if self.timeColor == "m_0" then
		self.timeColor = "m_63"
		self.dateColor = "m_63"


	else
		self.timeColor = "m_0"
		self.dateColor = "m_0"
		bgPath = bgPath .. "inverse_"
	end


	self.timeText:setProp{ color = self.timeColor }
	self.ndayText:setProp{ color = self.dateColor }
	self.dayText:setProp{ color = self.dateColor }
	self.monthText:setProp{ color = self.dateColor }


	bgPath = bgPath .. "ND.img"
	print ("Setting the background to: " .. bgPath)
	self.backgroundIcon:setProp{path = bgPath}
end






-- runCardsFile: Utility function that runs the cards.dat file from fms in an
-- empty environment that only has one function - "NotifyCard" defined in it.
-- and populates the "notifycards" table with the cards information in the
-- cards.dat file
--
--
--~ function readCards(path, functionTable)
--~   -- compiled function and compile status
--~   local f, err
--~   functionTable = functionTable or
--~                   { NotifyCard = function(card)
--~                                     notifycards[#notifycards + 1] = card
--~                                  end
--~                   }

--~   if startswith(path, "file:/") then
--~     local fp = io.open(path, "r")
--~     if not fp then
--~       print("Error in opening " .. path .. "\n")
--~       return
--~     else
--~       local contents = fp:read("*all")
--~       -- in the event that an update has caused all the data to be deleted
--~       -- from the file, the contents read out would be nil, and
--~       -- loadstring(nil) throws a Lua exception
--~       if not contents then
--~         return
--~       end
--~       f, err = loadstring(contents)
--~     end
--~   else
--~     f, err = loadfile(path)
--~   end

--~   if not f then
--~     print("Error in running " .. path .. ": " .. err .. "\n")
--~   else
--~     --
--~     -- NotifyCard: Helper function that is called with a card from each notification
--~     -- entry in cards.dat
--~     setfenv(f, functionTable)
--~     f()
--~   end
--~ end



--~ function updatecards()
--~   print("Update cards")
--~   notifycards = {}
--~   readCards(CARDS_FILE_PATH)

--~ end


--
-- The clock we are going to return
g_myNewClock = nil

--
-- startClock: The main entry point to the clock, returns a clock object
--
function newClock ()
  print ("Calling newClock")
  g_myNewClock = MyNewClock()

  if g_myNewClock == nil then
     return nil
  end



  return g_myNewClock
end

-- This is the table of all entry points into the clock
ClockEntries = {
  createclock = newClock
}

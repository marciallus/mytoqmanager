-- =============================================================================
--      Copyright (c) 2013-2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
-- ==============================================================================

----------------------
-- Global variables --
----------------------

oo = require "oo"   -- get the Object Oriented library
ui = require "ui"   -- get the UI library
dt = require "datetime"

--The Prism Clock class overrides the built-in Clock class
PrismClock = oo.class("PrismClock", ui.Clock)

-- Base part of zip files
g_appZip = "fms:/app.zip?"

-- The local time information widgets
g_timePrompt = nil

-- Starting color for the local information
g_timeColor = "m_63"

-- Background image icon
g_backgroundIcon = nil

function PrismClock:construct()
  print ("in construct")

  local layout = ui.Layout(self)

  -- draw the icon
  local bgPath = g_appZip .. "prism_inverse_ND.img"
  print (bgPath)

  g_backgroundIcon = layout:addIcon{path = bgPath}

  -- reset and the time prompt
  layout:resetGeometry()
  layout:addVerticalSpace(46)
  layout:direction(ui.LayoutDirection.VERTICAL)

  -- Time HH:MM
  local currentTimeModel = dt.DateTimeModel:getCurrentTime()
  layout:hAlign(ui.LayoutHAlign.CENTER)
  g_timePrompt = layout:addDateTime {
    value = currentTimeModel,
    format = "%I:%M", color = g_timeColor, 
    font = { size=110, weight = "light" }
  }

  -- Change colors to the first state
  self:changeColors()

  print ("Constructed")

  return 0
end

function PrismClock:updateTimeValues(timeModel)
  print("in updateTimeValues")
end

function PrismClock:changeColors()
  print("In changeColors: " .. g_timeColor)

  local bgPath = g_appZip .. "prism_"  
  if g_timeColor == "m_0" then
    g_timeColor = "m_63"
    bgPath = bgPath .. "inverse_"
  else
    g_timeColor = "m_0"
  end

  -- Update the time
  print("In changeColors: " .. g_timeColor)
  g_timePrompt:setProp{ color = g_timeColor }

  bgPath = bgPath .. "ND.img"
  print ("Setting the background to: " .. bgPath)
  g_backgroundIcon:setProp{path = bgPath}
end

function PrismClock:loadImages()
  return 0
end

--
-- The clock we are going to return 
g_prismClock = nil

-- 
-- startClock: The main entry point to the clock, returns a clock object
--
function newClock ()
  print ("Calling newClock")
  g_prismClock = PrismClock()

  return g_prismClock
end

-- This is the table of all entry points into the clock
ClockEntries = {
  createclock = newClock
}

-- =============================================================================
--      Copyright (c) 2013 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
-- ==============================================================================

app {
  name = "%NAME%",
  username = _("%NAME%"),
  icon_white = "fms:/app.zip?white.img",
  icon_color = "fms:/app.zip?color.img",
  entrypoints = "appentries",
}

--=============================================================================
--      Copyright (c) 2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
--==============================================================================
local i18n = require "i18n"

i18n.locales.en_US = {
  ["EMPTY DECK"] = "EMPTY DECK",
  ["Currently there are no cards in this application."]
  = "Currently there are no cards in this application."
}


--=============================================================================
--      Copyright (c) 2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
--==============================================================================
local i18n = require "i18n"

i18n.locales.zh_CN = {
  ["EMPTY DECK"] = "内容为空",
  ["Currently there are no cards in this application."]
  = "目前此应用程序中无任何卡片。"
}


-- =============================================================================
--      Copyright (c) 2013-2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
-- ==============================================================================


----------------------
-- Global variables --
----------------------


oo = require "oo"   -- get the Object Oriented library
ui = require "ui"   -- get the UI library
platform = require "platform" -- get the platform library
local i18n = require "i18n"

-- This is where all the notifications (cards.dat ones) currently available are stored
notifycards = {}
cardscount = 0

-- This is where all the popup cards are stored, indexed by card.id.
popupcards = {}

-- This is the list of cards, if there is at least 1 card in notifycards table,
-- otherwise it is nil
cardlist = nil

-- This is a text prompt that says "No cards available"
nocardsprompt = nil

-- This is a help message prompt that says "Check to see if notifications are
-- enabled"
helpmessage = nil

-- This is a reference (into popupcards table) of a card whose information
-- is (or needs to be) on the screen as a popup or details screen. Is usually
-- set in response to an app directed message.
popupcard = nil

-- This is a reference to a card which has just been removed from popupcards
-- and this card needs to be dismissed from UI display. Is usually set in
-- response to an app directed message.
deletecard = nil

-- cards currently open. Each entry in this table has a key of the card ID,
-- and each value is an array of three entries - the panel for the card,
-- the scrollable for the panel, and the index into openedcardsarray
-- (defined below)
openedcards = {}

-- Same openedcards list, this time stored as an array with [1] being the
-- oldest card
openedcardsarray = {}

-- Maximum number of popup cards we allow at a single time, older cards are
-- purged and their panels dismissed if more than MAX_POPUP_CARDS are opened
-- at a single time
MAX_POPUP_CARDS = 5

-- This is the table of all entry points into the app
appentries = {}

--------------
-- Classes  --
--------------

-- The CardList class overrides the built-in List widget to provide
-- the list of notifications.

CardList = oo.class("CardList", ui.List)


function CardList:onItemSelected(pos)
  print("Card Selected : " .. pos)
  showdetailscard(notifycards[pos + 1])
end

function CardList:onNewItem(posrect, index)
  print("In onnewitem : " .. index)
  local card
  card, _ = createnewcard(posrect, index)
  return card
end

function CardList:onItemHeight(index)
  if index >= cardscount then
    return nil
  end

  local l_rect = { left = 0, top = 0, bottom = 191, right = 287, }
  local card
  local height  -- height of the card
  card, height = createnewcard(l_rect, index)
  -- we need to destroy this card and all its children since its not being
  -- attached to a widget that is managed by the app manager
  card:destroy()
  return height
end


---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-- CallbackCtor --
-- construct a closure to an object and method.
-- Basically a call forwarding.
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
function CallbackCtor_Param1(obj, method)
  return function (p1)
    method(obj, p1)
  end
end


---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-- OptionsButton class --
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
OptionsCard = oo.class("OptionsCard", ui.Card)

function OptionsCard:init(index, card, optionValue)
  OptionsCard:superClass().init(self, {left = 0,
                                       top = 0,
                                       right = 268,
                                       bottom = 80,
                                       pos = index,
                                       idx = index + 1})
  self.card = card
  if card.version and 2 == card.version then
    self.optionText = optionValue[1]
  else
    self.optionText = optionValue  -- the string value
  end

  self:setProp {background = "m_63"}

  local l = ui.Layout(self)
  l:indent(5, 5)
  l:direction(ui.LayoutDirection.HORIZONTAL)
  l:hAlign(ui.LayoutHAlign.LEFT)
  l:vAlign(ui.LayoutVAlign.CENTER)
  l:setConstrainedWidth(230)
  l:addText{
    content = self.optionText, lines = 2, color = "m_0", 
    font = {size = 29}
  }
end

function OptionsCard:onClick()
  print("In OptionsCard:onClick()")
  sendnotification(self.card, "selected", self.optionText)
end


quickreplyPushObject = nil

QuickReplyNotify = oo.class("QuickReplyNotify", ui.quickreply)

function QuickReplyNotify:init(onnotify)
  self.superClass().init(self)
  self.notifycb = onnotify
end

function QuickReplyNotify:onNotify(message)
  self.notifycb(message)
end

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-- OptionsCard class --
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
QuickReplyCard = oo.class("QuickReplyCard", OptionsCard)

function QuickReplyCard:init(index, card, optionValue)
  QuickReplyCard:superClass().init(self, index, card, optionValue)
end

function QuickReplyCard:onNotify(sMessage)
  sendnotification(self.card, "selected", self.optionText, sMessage)
end

function QuickReplyCard:onClick()
  print("QuickReply card clicked")
  quickreplyPushObject = QuickReplyNotify(CallbackCtor_Param1(self, self.onNotify))
end


---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-- OptionsFrame class --
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
OptionsFrame = oo.class("OptionsFrame", ui.Frame)

function OptionsFrame:init(card)
  local numOptions = #card.options

  -- height of the option card is 
  -- 80 from the build spec
  -- + 6 separation between cards
  local cardHeight = 86
  local cardVerticalSpace = 6
  local frameWidth = 280
  local listWidth = 268
  local listLeft = 6
  local listTop = 6
  local frameHeight = (numOptions * cardHeight) + cardVerticalSpace

  self.superClass().init(self, {width = frameWidth, height = frameHeight,
                                color = "m_42"})

  local l = ui.Layout(self)
  l:direction(ui.LayoutDirection.VERTICAL)
  l:addVerticalSpace(6)
  l:indent(6, 6)

  for i, v in ipairs(card.options) do
    local b
    if "table" == type(v) and true == v[2] then
      b = QuickReplyCard(i, card, v)
    else
      b = OptionsCard(i, card, v)
    end
    l:appendWidget(b)
    l:addVerticalSpace(6)
  end
end

---------------------------------------------------------------------------------

-- The DetailsPanel class is used to show the details of a specific card.
-- We override various methods of the panel class.

DetailsPanel = oo.class("DetailsPanel", ui.Panel)

function DetailsPanel:init(card)
  self.superClass().init(self, {})
  self.card = card
end

function DetailsPanel:onClose()
  -- remove the reference from openedcards
  local idx = openedcards[self.card.id][3]
  table.remove(openedcardsarray, idx)
  openedcards[self.card.id] = nil
  sendnotification(self.card, "closed")
  self.superClass().onClose(self)
end

function DetailsPanel:onFocus()
  print("In panel onFocus")
  sendnotification(self.card, "visible")
  self.superClass().onFocus(self)
end

function DetailsPanel:onDefocus()
  print("In panel onDefocus")
  sendnotification(self.card, "invisible")
  self.superClass().onDefocus(self)
end



---------------
-- Functions --
---------------

--
-- sendnotification: Generates an app directed message to peer on Android
-- send cardevent only if the card is subscribed.
-- Generates a "CardEvent" message with ID and content such as "open",
-- "visible", "invisible" and "closed"
--
function sendnotification(card, content, data, data2)
  if card.cardevents and card.cardevents == "true" then
    contentmsg = "CardEvent { \n"
    contentmsg = contentmsg .. "id = \"" .. card.id .. "\",\n"
    contentmsg = contentmsg .. "event = \"" .. content .. "\",\n"
    if data then
      contentmsg = contentmsg .. "eventdata = \"" .. data .. "\",\n"
    end
    if data2 then
      contentmsg = contentmsg .. "eventdata2 = \"" .. data2 .. "\",\n"
    end
    contentmsg = contentmsg .. "}\n"
    sendmessage(contentmsg)
    -- print(contentmsg)
  end
end

--
-- populatedetailscard: Populates the actual scrollable panel with the
-- contents of the passed in card
--
--
function populatedetailscard(detailsscrollable, card)
  local panellayout = ui.Layout(detailsscrollable)
  panellayout:direction(ui.LayoutDirection.VERTICAL)
  panellayout:addVerticalSpace(9)
  panellayout:indent(23, 23)
  panellayout:hAlign(ui.LayoutHAlign.LEFT)

  if nil ~= card.app then
    panellayout:addText {
      content = card.app, lines = 4, color = "m_48",
      font = { size = 29 }
    }
  end

  if nil ~= card.time then
    panellayout:addDateTime {
       -- the notifycard/popupcard comes with time in millis, convert to seconds
       -- We are ok with truncating the value rather than rounding it
      value = card.time / 1000,
      format="%#b %d, %I:%M %p", relativeFormat="%#q %I:%M %p",
      color = "m_3",
      font = { size = 20, weight = "bold" }
    }
  end

  if nil ~= card.title then
    panellayout:addVerticalSpace(10)
    panellayout:addText {
      content = card.title, lines = 4, color = "m_0",
      font = { size = 24, weight = "bold" }
    }
  end

  -- TODO: Clip the picture
  if card.picture then
    panellayout:addVerticalSpace(3)
    panellayout:addIcon {image = ui.Image.new {path = card.picture}}
  end
  
  if card.detail then
    panellayout:addVerticalSpace(3)
    local dividerImage = nil

    -- determine if divider image is necessary
    if card.divider and card.divider == "true" then
      dividerImage = ui.Image.new {path = "fms:/app.zip?divider.img"}
    end

    -- render the details
    for i, v in ipairs(card.detail) do
      if i > 1 and dividerImage then
        panellayout:addIcon {image = dividerImage}
        panellayout:addVerticalSpace(6)
      end
      panellayout:addText {content = v, color = "m_0", font = { size = 26 }}
    end
  end

  if card.options then
    panellayout:addVerticalSpace(5)
    -- remove right indentation
    panellayout:indent(-15)
    panellayout:appendWidget(OptionsFrame(card))
  end
end


--
-- Common function to show the details card. Can be called if:
-- App is launched in order to show a popup (i.e. ongoing notification)
-- App is already launched and user selects a card 
-- Also generates app directed "opened" message for this card ID.
-- isPopupNotification if true, panel slide-transition is suppressed, and
-- the panel is made minimizable
--
function showdetailscard(card, isPopupNotification)
  print("Create details card with id [" .. card.id .. "]")

  local p = DetailsPanel(card)

  if isPopupNotification then p:setProp{ minimizeable = true } end

  local s = ui.Scrollable {
    left = 0, top = 0, right = 287, bottom = 191
  }

  p:add(s, true)  -- true == relative to container
  populatedetailscard(s, card)

  -- add the information to openedcards
  openedcardsarray[#openedcardsarray + 1] = card
  openedcards[card.id] = {p, s, #openedcardsarray}

  -- Notify Android peer that card is open
  sendnotification(card, "open");

  -- Push panel onto screen
  p:show(isPopupNotification or false)   -- panel transition default is ON.

end


--
-- updatedetailscard: Called for every PopupCard
-- app directed message. We check in here if
-- 1. There is a popup or details card on the screen
-- 2. The card ID matches the card ID for which we
--    have received the update.
-- 3. In that case, we update the details panel with
--    the latest information.
--
--
function updatedetailscard(card)

  if not openedcards[card.id] then 
    return false
  end

  print("Updating existing popup for " .. card.id)
  -- openedcards stores an array as its value with two members:
  -- the panel and the scrollable
  local p, s, idx = unpack(openedcards[card.id])

  -- Remove and destroy this scrollable from the panel, we are creating a new one
  s:destroy()
  s = ui.Scrollable {
    left = 0, top = 0, right = 287, bottom = 191
  }
  p:add(s, true)  -- relative to container

  -- add the information to openedcards
  openedcards[card.id] = {p, s, idx}
  populatedetailscard(s, card)
  p:show(true) -- suppress transition

  return true
end


--
-- createnewcard: create a new card for the given rectangle and using the card index to the
-- model. This card is shown in the first screen - the list of all notifications.
--
--
function createnewcard(posrect, index)
  if index >= cardscount then
    return nil
  end
  
  local mycard = ui.Card { left = posrect.left, right = posrect.right,
                           top = posrect.top, bottom = posrect.bottom,
                           pos = index, idx = index + 1 }
  local cardlayout = ui.Layout(mycard)
  cardlayout:addVerticalSpace(9)
  cardlayout:direction(ui.LayoutDirection.VERTICAL)
  cardlayout:indent(17, 17)
  cardlayout:hAlign(ui.LayoutHAlign.LEFT)
  
  if notifycards[index + 1].app then
    cardlayout:addText {
      content = notifycards[index + 1].app, lines = 1, color = "m_48",
      font = { size = 29 }
    }
  end

  if notifycards[index + 1].time then
    cardlayout:addDateTime {
      -- the notifycard comes with time in millis, convert to seconds
      -- We are ok with truncating the value rather than rounding it
      value = notifycards[index + 1].time / 1000,
      format="%#b %d, %I:%M %p", relativeFormat="%#q %I:%M %p",
      color = "m_3",
      font = { size = 20, weight = "bold" }
    }
  end
  
  cardlayout:addVerticalSpace(10)
  
  if notifycards[index+1].title then
    cardlayout:addText {
      content = notifycards[index+1].title, lines = 1, color = "m_0",
      font = { size = 24, weight = "bold" }
    }
  end

  if  notifycards[index+1].detail then
    cardlayout:addText {
      content = table.concat(notifycards[index+1].detail, "\n"), lines = 2, color = "m_0",
      font = { size = 26 }
    }
  end

  cardlayout:addVerticalSpace(4)   -- add additional space ending the card
  
  return mycard, cardlayout:height()
end


-- 
-- NotifyCard: Helper function that is called with a card from each notification
-- entry in cards.dat
function NotifyCard (card)
  cardscount = cardscount + 1
  notifycards[cardscount] = card
end

--
-- runCardsFile: Utility function that runs the cards.dat file in an empty
-- environment that only has one function - "NotifyCard" defined in it.
--
--
function runCardsFile(path)
  f, err = loadfile(path)
  if not f then
    print("Error in running " .. path .. ": " .. err .. "\n")
  else
    setfenv(f, { NotifyCard = NotifyCard })
    f()
  end
end

--
-- readCards: reads the cards.dat file from fms, which populates the
-- "NotifyCards" table with the cards information in cards.dat file.
--
--
function readCards()
  runCardsFile("fms:/cards.dat")
end

--
-- removeEmptyPrompt: Is called to remove any existing "No Android notifications"
-- prompt and the help message that goes with it.
--
--
function removeEmptyPrompt(targetpanel)
  if nocardsprompt then
    nocardsprompt:destroy()
    nocardsprompt = nil
  end
  if helpmessage then
    helpmessage:destroy()
    helpmessage = nil
  end
end

--
-- addEmptyPrompt: Is called to add an empty "No Android notifications" prompt
--
--
function addEmptyPrompt(targetpanel)
  targetpanel:setProp{ background = "m_63" }  -- change background to white
  removeEmptyPrompt(targetpanel)
  local panellayout = ui.Layout(targetpanel)
  panellayout:addVerticalSpace(19)
  panellayout:indent(19, 80)
  nocardsprompt = panellayout:addText {
    content = i18n"EMPTY DECK", 
    lines = 2, color = "m_3",
    font = { size = 20, weight = "bold"}
  }

  panellayout:resetGeometry()
  panellayout:addVerticalSpace(70)
  panellayout:indent(19, 19)
  helpmessage = panellayout:addText {
    content = i18n"Currently there are no cards in this application.",
    lines = 0, color = "m_0",
    font = { size = 26 }
  }

end

--
-- populate: Populates the provided panel with the list of cards in cardlist
-- This creates the main startup screen of the app
--
--
function populate(targetpanel)
  if cardscount == 0 then
    -- If there was an existing list of cards, need to remove it from
    -- the panel and destroy it
    if cardlist then
      cardlist:destroy()
      cardlist = nil
    end

    addEmptyPrompt(targetpanel)
  else
    if cardlist then
      -- In the case where there are cards available, and a previous cardlist exists
      -- we can simply reset the cardlist to repopulate it
      print("CardList resizing. For " .. cardscount .. " cards.")
      cardlist:reset(cardscount)

      -- update any existing details screens
      for i, v in ipairs(notifycards) do
        if openedcards[v.id] then
          updatedetailscard(v)
        end
      end
    else
      -- Remove the nocardsprompt from the panel if its there
      removeEmptyPrompt(targetpanel)

      targetpanel:setProp{ background = "m_27" }  -- change background to 27

      -- If no previous cardlist, then create one and add to panel
      cardlist = assert(CardList { left = 0, top = 0, bottom = 191, right = 287,
                                   numitems = cardscount, itemheight = 160 },
                        "Card list creation failed")
      targetpanel:add(cardlist, true)  -- relative to container
    end
  end
  -- force a gc cycle to reclaim the old cards and prompts, otherwise too much
  -- fragmentation is being created. 
  -- Better management of garbage collection will move into the framework in the
  -- future
  collectgarbage("collect")
end

--
-- initcards: read and initialize mainpanel with the data from cards.dat
--
--
function initcards()
  notifycards = {}
  cardscount = 0
  readCards()
  populate(mainpanel)
end

--
-- cardsupdated: Is called in response to fms file cards.dat being updated
--
--
function cardsupdated(file)
  print("Cards updated")
  initcards()   -- re-initialize cards
end

CardsMonitor = oo.class("CardsMonitor", platform.FMSMonitor)


function CardsMonitor:onUpdate(path)
  cardsupdated(path)
  return 0
end

function CardsMonitor:onDelete(path)
  cardsupdated(path)
  return 0
end

function CardsMonitor:onParentDelete(path)
  cardsupdated(path);
  return 0
end

MainPanel = oo.class("MainPanel", ui.Panel)

function MainPanel:init(args)
  self.superClass().init(self, args)
end

function MainPanel:onClose()
  mainpanel = nil
  cardlist = nil
  nocardsprompt = nil
  helpmessage = nil
end

-- 
-- onStart: The main entry point to the app. Can optionally return a panel
--
--
function appentries:onStart()
  i18n.setLocale(platform.getCurrentLocale())
  if not mainpanel then   -- create once
    mainpanel = assert(MainPanel( { color = "m_27" } ), 
                       "Main panel creation failed")
  end

  initcards()
  
  if not fms_listener then   -- register once
    fms_listener = assert(CardsMonitor ( { path = "fms:/cards.dat"} ),
                          "FMS monitor failed")
  end
  
  return mainpanel
end

--
-- onStop: Called when the app is about to be stopped
--
--
function appentries:onStop()
  if fms_listener then
    fms_listener:destroy()
    fms_listener = nil
  end
end


--
-- removeoldestcard: Removes the oldest popupcard in the openedcards list. Also
-- dismisses the card's panel
--
--
function removeoldestcard()
  local cardtoremove = openedcardsarray[1]
  print("Removing oldest card with id " .. cardtoremove.id);
  popupcards[cardtoremove.id] = nil
  local p = openedcards[cardtoremove.id][1]
  p:dismiss()
end

-- 
-- PopupCard: This can be one of the instructions inside
-- a received app directed message. The other
-- instruction is DeleteCard {}
--
--
function PopupCard(card)
  print("PopupCard for card id " .. card.id)
  popupcards[card.id] = card
  popupcard = card
end

-- 
-- DeleteCard: Can be an instruction inside a received
-- app directed message. (The other one is 
-- PopupCard {} )
function DeleteCard(card)
  print("DeleteCard for card id " .. card.id)
  if popupcards[card.id] then
    print("DeleteCard: Found card")
    deletecard = popupcards[card.id]
    popupcards[card.id] = nil
  else
    print("DeleteCard: Not found")
  end
end

--
--
function isVibeSuppressed(card)
  if card.suppressvibe and card.suppressvibe == "true" then
    return true
  end
  return false
end

--
-- onMessage: The designated app directed message handler for this app
--
-- onMessage is given a chunk of Lua code that it needs to execute
-- What happens when that chunk of Lua code runs is defined by the 
-- app itself. In the case of notification manager, we are expecting
-- PopupCard {} and DeleteCard {} calls in the app directed message
-- Thus we run the chunk in an env where only those two functions are
-- defined
--
--
function appentries:onMessage(messagefunc)
  print("Received App directed message")
  setfenv(messagefunc, { PopupCard = PopupCard, DeleteCard = DeleteCard })
  messagefunc()

  if popupcard then
    -- First attempt to update an existing card, if it does not match, then
    -- show a new card.
    if not updatedetailscard(popupcard) then
      -- We need to create a new popup. Since we only allow MAX_POPUP_CARDS at
      -- a time, check to see if we need to expire an old card
      if #openedcardsarray == MAX_POPUP_CARDS then
        print("Max cards exceeded, removing oldest card")
        removeoldestcard()
      end
      print("Creating new popup card for " .. popupcard.id)
      -- suppress slide-transitions for alerts.
      showdetailscard(popupcard, true)
    end

    -- donot vibe if suppressed
    if not isVibeSuppressed(popupcard) then
      devicemgr.set_vibe(devicemgr_vibe.short)
    end

    -- activate touch
    devicemgr.activate_touch(devicemgr_touch_activity.notification)
  end

  if deletecard then
    if openedcards[deletecard.id] then
      local p = openedcards[deletecard.id][1]
      p:dismiss()
    end
  end

  popupcard = nil
  deletecard = nil
  -- Force a gc cycle to reclaim the old cards and prompts, otherwise too 
  -- much fragmentation is being created. 
  -- This needs to move into the framework
  collectgarbage("collect")
  return false
end


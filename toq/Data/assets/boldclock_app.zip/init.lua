-- =============================================================================
--      Copyright (c) 2013-2014 Qualcomm MEMS Technology, Inc
--           All Rights Reserved
--        QMT Proprietary and Confidential
-- ==============================================================================

----------------------
-- Global variables --
----------------------

oo = require "oo"   -- get the Object Oriented library
ui = require "ui"   -- get the UI library
dt = require "datetime"
platform = require "platform"
string = require "string"
io = require "io"   -- get the IO library


-- This is where all the notifications (cards.dat ones) currently available are stored
notifycards = {}

-- This is where all the popup cards are stored, indexed by card.id.
popupcards = {}

-- This is where all the data cards are stored, indexed by card.id.
datacards = {}

-- This is the list of cards, if there is at least 1 card in notifycards table,
-- otherwise it is nil
cardlist = nil

-- Maximum number of popup cards we allow at a single time, older cards are
-- purged and their panels dismissed if more than MAX_POPUP_CARDS are opened
-- at a single time
MAX_POPUP_CARDS = 6

CARDS_FILE_PATH = "fms:/../com.qualcomm.qce.androidnotifications/cards.dat"


--The Degrees Clock class overrides the built-in Clock class
MyBoldClock = oo.class("MyBoldClock", ui.Clock)

function MyBoldClock:construct()
  print ("in construct")

  -- Base part of zip files
  self.appZip = "fms:/app.zip?"

  local layout = ui.Layout(self)

  -- draw the icon
  local bgPath = self.appZip .. "boldclock_inverse_ND.img"
  print (bgPath)

  self.backgroundIcon = layout:addIcon{path = bgPath}



  -- reset and the time prompt
  local textLeftMargin = 10


	self.icon = {}

  self.month = "ABC"
  self.monthDay = "00"
  self.charGap = 14

  self.timeColor = "m_22"
  self.timeFont = { size=25, weight = "bold" }

  local textRightMargin = 264
-- notifications

	updatecards()


   layout:resetGeometry()
   layout:indent(0, 0)
   layout:direction(ui.LayoutDirection.HORIZONTAL)

	for card in 1,MAX_POPUP_CARDS do

		local iconpath = "fms:/app.zip?small.img"
		if (i < (#notifycards+1)) then
			iconpath = notifycards[i].icon or "fms:/app.zip?small.img"
		end

		self.icon[i] = layout:addIcon {
			path = iconpath,
			altpath = "fms:/app.zip?small.img"
		}

	end


-- Month Day
  layout:resetGeometry()
  layout:addVerticalSpace(40)
  layout:indent(0, textRightMargin)
  layout:direction(ui.LayoutDirection.HORIZONTAL)
  layout:hAlign(ui.LayoutHAlign.LEFT)
  layout:setConstrainedWidth(30)

  self.monthDayText1 = layout:addText {
     content = self.monthDay:sub(1, 1),
     color = self.timeColor,
     font = self.timeFont,
  }

  self.monthDayText2 = layout:addText {
     content = self.monthDay:sub(2, 2),
     color = self.timeColor,
     font = self.timeFont,
  }

 -- Month

  layout:resetGeometry()
  layout:addVerticalSpace(70)
  layout:indent(0, textRightMargin)
  layout:direction(ui.LayoutDirection.HORIZONTAL)
  layout:hAlign(ui.LayoutHAlign.LEFT)
  layout:setConstrainedWidth(30)

  self.monthText1 = layout:addText {
     content = self.month:sub(1, 1),
     color = self.timeColor,
     font = self.timeFont,
  }

  self.monthText2 = layout:addText {
     content = self.month:sub(2, 2),
     color = self.timeColor,
     font = self.timeFont,
  }

  self.monthText3 = layout:addText {
     content = self.month:sub(3, 3),
     color = self.timeColor,
     font = self.timeFont,
  }



  -- Change colors to the first state
  self:changeColors()

  print ("Constructed")

  return 0
end

function MyBoldClock:moveText(x, text)
  local coords = text:getCoords()
  text:move(x, coords.top)
end

function MyBoldClock:getTextLeft()




 -- (-20) is the edge of the clock dots
 local clockRight =  20
 local parentCoords = self:getCoords()

 -- local outerWidth = parentCoords.right - clockRight + 1
 local outerWidth = clockCoords.left

 local strWidth, _ = self.monthText1:getStringBBox(self.month, self.timeFont)
 local innerWidth = strWidth + (2 * self.charGap)

 return math.floor((outerWidth - innerWidth)/2)

end

function MyBoldClock:updateTimeValues(timeModel)

	updatecards()
	for card in 1,MAX_POPUP_CARDS do

		local iconpath = "fms:/app.zip?small.img"
		if (i < (#notifycards+1)) then
			iconpath = notifycards[i].icon or "fms:/app.zip?small.img"
			self.icon[i]:setProp{path = iconpath,visible = true }
		else
			self.icon[i]:setProp{path = iconpath,visible = false }
		end

		self.icon[i] = layout:addIcon {
			path = iconpath,
			altpath = "fms:/app.zip?small.img"
		}

	end

	 self.minuteIcon2:setProp{path = m2Path,visible = true }

  -- local newDay = timeModel:getTimeString("%#a")
  local newMonth = timeModel:getTimeString("%#b")
  local newMonthDay = timeModel:getTimeString("%#d")

  if newMonth == self.month and
     newMonthDay == self.monthDay then
    -- and newhDay == self.day
     -- Optimization
     print ("Nothing to do the date hasn't changed")
     return
  end

  print ("Updating the date to " .. " " .. newMonth .. " " .. newMonthDay)
  -- self.day = newDay
  self.month = newMonth
  self.monthDay = newMonthDay

  -- Set the text on the three month text boxes
  -- and move them into position

  -- First letter of the Month
  local textLeft = self:getTextLeft()
  -- self:moveText(textLeft, self.dayText1)
  self:moveText(textLeft, self.monthText1)
  self:moveText(textLeft, self.monthDayText1)

  local newText = self.month:sub(1, 1)
  local strWidth, _ = self.monthText1:getStringBBox(newText, self.timeFont)
  self.monthText1:setProp{ content = newText }

  -- Second letter of the Month
  newText = self.month:sub(2, 2)
  self.monthText2:setProp{ content = newText }
  textLeft = textLeft + strWidth + self.charGap
  self:moveText(textLeft, self.monthText2)

  -- We need this for the month day
  local textLeft2 = textLeft

  -- Third letter of the Month
  strWidth, _ = self.monthText2:getStringBBox(newText, self.timeFont)
  textLeft = textLeft + strWidth + self.charGap

  self.monthText3:setProp{ content = self.month:sub(3, 3) }
  self:moveText(textLeft, self.monthText3)

  -- Set the text on the monthDay text boxes or hide it
  self.monthDayText1:setProp{ content = self.monthDay:sub(1, 1) }
  if #self.monthDay > 1 then
     -- coords is at the middle month char
     self.monthDayText2:setProp {
        content = self.monthDay:sub(2, 2),
        visible = true}
     self:moveText(textLeft2, self.monthDayText2)
  else
     self.monthDayText2:setProp {visible = false}
  end
end

function MyBoldClock:changeColors()
  print("In changeColors: " .. self.timeColor)

  local bgPath = self.appZip .. "boldclock_"
  if self.timeColor == "m_41" then
    self.timeColor = "m_22"
    self.handColor = "m_56"
    bgPath = bgPath .. "inverse_"
  else
    self.timeColor = "m_41"
    self.handColor = "m_7"
  end

  -- Update the time
  print("In changeColors: " .. self.timeColor)
  self.analogClock:setProp{ handColor = self.handColor }


  self.monthText1:setProp{ color = self.timeColor }
  self.monthText2:setProp{ color = self.timeColor }
  self.monthText3:setProp{ color = self.timeColor }

  self.monthDayText1:setProp{ color = self.timeColor }
  self.monthDayText2:setProp{ color = self.timeColor }

  bgPath = bgPath .. "ND.img"
  print ("Setting the background to: " .. bgPath)
  self.backgroundIcon:setProp{path = bgPath}
end






-- runCardsFile: Utility function that runs the cards.dat file from fms in an
-- empty environment that only has one function - "NotifyCard" defined in it.
-- and populates the "notifycards" table with the cards information in the
-- cards.dat file
--
--
function readCards(path, functionTable)
  -- compiled function and compile status
  local f, err
  functionTable = functionTable or
                  { NotifyCard = function(card)
                                    notifycards[#notifycards + 1] = card
                                 end
                  }

  if startswith(path, "file:/") then
    local fp = io.open(path, "r")
    if not fp then
      print("Error in opening " .. path .. "\n")
      return
    else
      local contents = fp:read("*all")
      -- in the event that an update has caused all the data to be deleted
      -- from the file, the contents read out would be nil, and
      -- loadstring(nil) throws a Lua exception
      if not contents then
        return
      end
      f, err = loadstring(contents)
    end
  else
    f, err = loadfile(path)
  end

  if not f then
    print("Error in running " .. path .. ": " .. err .. "\n")
  else
    --
    -- NotifyCard: Helper function that is called with a card from each notification
    -- entry in cards.dat
    setfenv(f, functionTable)
    f()
  end
end



function updatecards()
  print("Update cards")
  notifycards = {}
  readCards(CARDS_FILE_PATH)

end


--
-- The clock we are going to return
g_myBoldClock = nil



--
-- startClock: The main entry point to the clock, returns a clock object
--
function newClock ()
  print ("Calling newClock")
  g_myBoldClock = MyBoldClock()

  if g_myBoldClock == nil then
     return nil
  end



  return g_myBoldClock
end

-- This is the table of all entry points into the clock
ClockEntries = {
  createclock = newClock
}
